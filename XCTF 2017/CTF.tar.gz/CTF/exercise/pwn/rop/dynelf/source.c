/**
 * compile cmd: gcc source.c -fno-stack-protector -o bin
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>


void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(void) {
	char buffer[0x30];
	init();
    puts("**************************************");
    puts("welcome to exploit train");
    puts("**************************************");
	read(STDIN_FILENO, buffer, 0x100);
	return 0;
}
