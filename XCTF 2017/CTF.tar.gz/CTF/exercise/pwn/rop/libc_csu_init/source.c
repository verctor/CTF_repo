/**
 * compile cmd: gcc source.c -fno-stack-protector -masm=intel -o bin
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

char *const exec_argv[] = {"false", NULL};

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void fun() {
    char buffer[0x40];
    fwrite("**************************************\n", 39, 1, stdout);
    fwrite("welcome to rop train\n", 21, 1, stdout);
    fwrite("**************************************\n", 39, 1, stdout);

    read(STDIN_FILENO, buffer, 0x200);
    fwrite("good luck\n", 10, 1, stdout);
    __asm__("mov rsi,0xdeadbeefdeadbeef");
    __asm__("mov rdi,0xdeadbeefdeadbeef");
    __asm__("mov rcx,0xdeadbeefdeadbeef");
    __asm__("mov rdx,0xdeadbeefdeadbeef");
    __asm__("mov r8,0xdeadbeefdeadbeef");
    __asm__("mov r9,0xdeadbeefdeadbeef");
}

int main(int argc, char * argv[],  char *envp[]) {
    init();
    fun();
    execve("/bin/false", exec_argv, envp);
}
