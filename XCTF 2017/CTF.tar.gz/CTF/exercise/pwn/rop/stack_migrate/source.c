/**
 * compile cmd: gcc source.c -fno-stack-protector -o bin
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

char *const exec_argv[] = {"false", NULL};

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(void) {
    char buf[0x20];
    init();
    write(STDOUT_FILENO, "welcome\njust have a try~\n", 25);
    read(STDIN_FILENO, buf, 48);
}
