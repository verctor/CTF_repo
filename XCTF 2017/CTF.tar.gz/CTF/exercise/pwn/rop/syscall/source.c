/**
 * compile cmd: gcc source.c -static -fno-stack-protector -o bin
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>


void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(void) {
	char buffer[0x30];
	init();
    puts("**************************************");
    puts("welcome to exploit train");
    puts("**************************************");
	puts("So can you get my shell without system function?");
	gets(buffer);	
}
