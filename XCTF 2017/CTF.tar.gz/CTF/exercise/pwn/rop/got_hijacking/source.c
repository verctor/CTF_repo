/**
 * compile cmd: gcc source.c -z execstack -o bin
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

char *stuTable[30];

int readn(char * buffer, int length, char end) {
	int i,re;
	char ch;
	for(i = 0; i < length - 1; i++) {
		re = read(STDIN_FILENO, &ch, 1);
		if(ch == end) {
			break;
		}
		*(buffer + i) = ch;
	}
	*(buffer + i) = 0;
	return i+1;
}

int readNum(void) {
	char buf[20];
	readn(buf, 20, '\n');
	return atoi(buf);
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

void putMenu() {
	puts("1.add student");
	puts("2.edit student");
	puts("3.delete student");
	puts("4.show student");
	puts("5.exit");
	puts("give me choose:");
}

void add() {
	int num;
	char * name;
	puts("give me student number");
	num = readNum();
	puts("give me student name");
	name = malloc(0x100);
	if(name == NULL) {
		puts("malloc faild");
		return;
	}
	read(STDIN_FILENO, name, 0x100);
	stuTable[num] = name;
	puts("success");
}

int main() {
	int choose;
	init();
	puts("welcome to student database");
	while (1) {
		putMenu();
		choose = readNum();
		if(choose == 1) {
			add();
		}
		else if(choose == 2 || choose == 3 || choose == 4) {
			puts("TODO");
		}
		else {
			break;
		}
	}
}
