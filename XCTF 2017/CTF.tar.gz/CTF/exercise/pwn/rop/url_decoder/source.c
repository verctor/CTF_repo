/**
 * compile cmd: gcc source.c -O2 -m32 -fno-stack-protector -o bin
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>

void handler()
{
    exit(0);
}
char *getUrl()
{
    int i;
    char *Url;
    int size;
    char ch,ch1;

    Url = malloc(9);
    if(!Url)
    {
        puts("Error: malloc failed.");
        exit(1);
    }
    size = 8;

    for(i=0;;i++)
    {
        ch = getc(stdin);
        ch1 = ch;
        if(ch == EOF)
        {
            puts("Error: EOF Detected.");
            exit(1);
        }

        if(ch == 10)
            break;

        if(i > size)
        {
            Url = realloc(Url,size + 9);
            if(!Url)
            {
                puts("Error: realloc failed.");
                exit(1);
            }
            size += 8;
        }

        *(Url +i) = ch1;
    }

    *(Url + i) = 0;
    return Url;
}

void showUrl(char *str)
{
    char buf[0x80];
    char chr;
    char nptr[3];
    int len;
    char * i;

    len = strlen(str);
    if(len > 127)
    {
        puts("Error: input is too long.");
        exit(1);
    }

    if( len <= 7)
    {
        puts("Error: input is too short.");
        exit(1);
    }

    if( memcmp(str,"http://",7))
    {
        puts("Error: url should start with \'http://\'");
        exit(1);
    }

    memset(buf,0,sizeof(buf));
    chr = *str;
    
    for(i=buf; chr; chr = *(++str))
    {    
        if(chr!=37)
        {
            *i = chr;
            i++;
        }
        else
        {
            nptr[0] = str[1];
            nptr[1] = str[2];
            nptr[2] = 0;
            *i = strtol(nptr,0,16);
            i++;
            str +=2;
        }
    }
    printf("Decode Result: %s\n", buf);
    return;
}

int main(void)
{
    char *Url;
    setbuf(stdout,0);
    setbuf(stdout,0);

    signal(14,handler);
    alarm(0x3cu);

    puts("<<< Online URL Decoder >>>");
    printf("URL: ");

    Url = getUrl();
    showUrl(Url);
    free(Url);
}
