#include <unistd.h>

int main(){
    char buffer[0x20];
    read(0,buffer,0x30);
    write(1,buffer,0x30);
    return 0;
}
