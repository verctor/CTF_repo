#include <unistd.h>
#include <string.h>
int main(){
    char buffer[0x20];
    read(0,buffer,0x100);
    atoi(buffer);
    return 0;
}
