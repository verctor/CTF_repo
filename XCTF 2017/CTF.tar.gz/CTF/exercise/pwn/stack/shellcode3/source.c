/**
* compile cmd: gcc source.c -m32 -o bin
**/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sched.h>

void init();
int fn(void *);
void set_uid_map(pid_t, uid_t, uid_t, int);
void set_gid_map(pid_t, gid_t, gid_t, int);
void exec_shellcode();

uid_t uid;
gid_t gid;
pid_t pid;
char stack[0x100000];


int main(void) {
	pid_t childPid;
	uid = getuid();
	gid = getgid();
	pid = getpid();

	childPid = clone(&fn, stack+0x100000, 0x10000011, 0);
	waitpid(childPid, 0, 0);
	return 0;
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int fn(void * args) {
	pid_t childPid;
	set_uid_map(getpid(), 0, uid, 1);
	set_gid_map(getpid(), 0, gid, 1);
	chdir("jail");

	childPid = fork();
	if(childPid < 0) {
		puts("fork faild");
		exit(0);
	}
	if(!childPid) {
		if(chroot("./") != 0) {
			puts("chroot faild");
			exit(0);
		}
		puts("No one can escaping from my jail");
		exec_shellcode();
		exit(0);
	}
	waitpid(childPid, 0, 0);
}

void set_uid_map(pid_t p, uid_t udest, uid_t usrc, int len) {
	char buffer[0x100];
	FILE *fp;
	sprintf(buffer, "/proc/%d/uid_map", p);
	fp = fopen(buffer, "w");
	fprintf(fp, "%d %d %d", udest, usrc, len);
	fclose(fp);
}

void set_gid_map(pid_t p, gid_t gdest, gid_t gsrc, int len) {
	char buffer[0x100];
	FILE *fp;
	sprintf(buffer, "/proc/%d/gid_map", p);
	fp = fopen(buffer, "w");
	fprintf(fp, "%d %d %d", gdest, gsrc, len);
	fclose(fp);
}

void exec_shellcode() {
	char *memory;
	char tmp;
	int i,re;
	void (*fun)();
	init();
	memory = mmap(NULL, 4096, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, 0, 0);
	
	for(i = 0; i < 4096; i++){
        re = read(STDIN_FILENO, &tmp, 1); 
        if(re == -1) {
            exit(0);
        }
        if(tmp != 0 && tmp != '\n') {
            *(memory+i) = tmp;
        } else {
            break;
        }
    }
	fun = (void (*)())memory;
	
	fun();
}
