/**
* compile cmd: gcc source.c -m32 -fno-stack-protector -z execstack -o bin
**/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NU
    	LL);
    setbuf(stderr, NULL);
}

void initMemory() {
	FILE *fp;
	char *mem;
	int seed;
	int i,j;
	int num;
	fp = fopen("/dev/urandom", "w");
	fread(&seed, 4, 1, fp);
	fclose(fp);

	srand(seed);
	for(i = 0; i < 256; i++) {
		num = rand()&0xff;
		mem = malloc(num);
		for(j = 0; j < num; j++) {
			mem[j] = rand()&0xff;
		}
	}
}

int main(void) {
	char * buffer;
	int choose;
	char tmp[20];
	void (*fun)();
	init();
	printf("some hint for you %p\n", malloc(0x100));
	initMemory();
	puts("do you have some word to say?");
	while(1) {
		buffer = malloc(0x200);
		read(STDIN_FILENO, buffer, 0x200);
		puts("more word to say?");
		read(STDIN_FILENO, &choose, 4);
		if((char)choose == 'n') {
			break;
		}
		puts("ok! give me word:");
	}
	puts("finaly, give me a magic number");
	fgets(tmp, 20, stdin);
	fun = atoi(tmp);
	puts("good luck :)");
	fun();
}
