/**
* compile cmd: gcc source.c -m32 -fno-stack-protector -z execstack -o bin
**/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

void hint(){
	__asm__("jmp *%esp");
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}


int main(void) {
	char buffer[100];
	init();
	puts("**************************************");
	puts("welcome to exploit train");
	puts("**************************************");
	read(STDIN_FILENO, buffer, 0x200);
	puts("see you~~");
}
