/**
* compile cmd: gcc source.c -m32 -fno-stack-protector -o bin
**/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>

void init() {
	setbuf(stdin, NULL);
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
}

int main(void) {
	char *memory;
	void (*map)();
	char *getPos;
	memory = mmap((void *)0x31337000, 4096, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, 0, 0);
	map = (void (*)())memory;
	getPos = memory + 4090;
	gets(getPos);
	strncpy((char *)map, getPos, 5);
	map();
	return 0;
}
