/**  
* compile cmd: gcc source.c -m32 -o bin
**/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(void) {
    char* memory;
	void (*fun)();
	char tmp;
	int re,i;
    init();
    puts("**************************************");
    puts("welcome to exploit train");
	puts("I can only understand uppercase and digits");
    puts("**************************************");

	memory = mmap(NULL, 4096, PROT_EXEC | PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANON, 0, 0);
	for(i = 0; i < 4096; i++){
		re = read(STDIN_FILENO, &tmp, 1);
		if(re == -1) {
			exit(0);
		}
		if((tmp<91&&tmp>64) || (tmp>47&&tmp<58)) {
			*(memory+i) = tmp;
		} else {
			break;
		}
	}
	fun = memory;
	fun();
}
