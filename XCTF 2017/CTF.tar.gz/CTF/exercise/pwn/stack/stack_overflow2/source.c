/**
** compile cmd: gcc source.c -fno-stack-protector -m32 -o bin
**/
#include <stdio.h>
#include <unistd.h>

void getflag(void) {
    char flag[100];
    FILE *fp = fopen("./flag", "r");
    if (fp == NULL) {
        puts("get flag error");
    }
    fgets(flag, 100, fp);
    puts(flag);
}

void init() {
    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
}

int main(void) {
    char buffer[100];
	init();
    read(STDIN_FILENO,buffer,116);
}
