#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int read_buf(char * buf,int len,char end){
	char ch;
	int i;
	for(i=0;i<len;i++){
		if (read(0,&ch,1)<=0){
			exit(-1);
		}

		if (ch == end)
			break;

		buf[i]=ch;
	}

	buf[i]=0;
	return i;
}

void check(char * fmt,char * name,char * pwd){
	char buf[64];
	printf("[debug] ptr fmt: %p\n",&fmt);
	printf("[debug] ptr buf: %p\n",&buf);
	sprintf(buf,fmt,name,pwd);
	puts("success!");
	puts(buf);
}

int main(void){
	setbuf(stdin,0);
	setbuf(stdout,0);
	setbuf(stderr,0);

	puts("welcome to the fmt test!");
	char * name = (char *)malloc(0x100);
	char * pwd = (char *)malloc(0x100);
	char fmt[8] ;

	puts("input your name:");
	read_buf(name,0x100,'\n');

	puts("input your pwd:");
	read_buf(pwd,0x100,'\n');

	strcpy(fmt, "%s:%s");

	printf("[debug] ptr fmt_content: %p\n",fmt);

	check(fmt,name,pwd);

	return 0;
}
