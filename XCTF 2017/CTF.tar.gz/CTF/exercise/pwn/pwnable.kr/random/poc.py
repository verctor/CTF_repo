from pwn import *
context.log_level = 'debug'

rr = 1
if rr:
	cn = ssh(host='pwnable.kr',user='random',password='guest',port=2222).process("./random")
else:
	cn = process('./random')

rnd=0x6b8b4567

check=0xDEADBEEF

cn.sendline(str(rnd^check))
cn.recv()