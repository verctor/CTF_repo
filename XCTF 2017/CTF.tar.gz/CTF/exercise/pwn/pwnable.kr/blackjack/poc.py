from pwn import *
#context.log_level = 'debug'

cn = remote('0.0.0.0', 9009)

cn.recv()
cn.sendline('y')
cn.recv()
cn.sendline('1')

new=1
while 1:
	if new:
		print cn.recvuntil('$')
		cash = int(cn.recvuntil('\n'))
		new=0
	cn.recvuntil('Your Total is ')
	total = int(cn.recvuntil('\n'))
	cn.recvuntil('The Dealer Has a Total of ')
	his_total = int(cn.recvuntil('\n'))
	cn.recv()
	print 'cash:%d , total:%d , his_total:%d' % (cash,total,his_total)
	cn.sendline(str((cash/2)))

	cn.recv()
	if his_total >= 21:
		cn.sendline('Y')
		new=1
		continue
	if total < 18:
		cn.sendline('H')
	else:
		cn.sendline('S')
		cn.sendline('Y')
		new=1