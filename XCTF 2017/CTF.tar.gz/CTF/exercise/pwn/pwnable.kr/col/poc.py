from pwn import *
#context.log_level = 'debug'

check = 0x0121dd09ec

code = '0000'*4 + hex(check-int('0000'.encode('hex'),16)*4)[2:].decode('hex')[::-1]

pwn_ssh = ssh(host='pwnable.kr',user='col',password='guest',port=2222)

cn = pwn_ssh.process(argv=['col',code],executable='./col')

print cn.recv()