from pwn import *
context.log_level = 'debug'

cn = remote('0.0.0.0',9007)

cn.recv()

sleep(3)
for times in range(100):
	a = cn.recv().split('=')
	n = int(a[1][:-2])
	c = int(a[2][:-1])
	left=0
	right=n-1
	mid=(left+right)/2
	for i in xrange(c):
		str_ask=[str(n) for n in xrange(left,mid+1)]  
		str_ask=" ".join(str_ask)
		cn.sendline(str_ask)
		weight=int(cn.recv())  
		print "weight = %d l=%d mid=%d r=%d"%(weight,left,mid,right)  
		if weight!=((mid-left+1)*10):  
			right=mid  
			mid=(right+left)/2  
		else:  
			left=mid+1  
			mid=(left+right)/2  
	cn.sendline(str(mid))  
	ans=cn.recvline()
	print "ans=",ans  
print cn.recv()

