from pwn import *

cn = process('./Raaa')

cn.sendline(str(0x6b8b4567^0x23333333))
cn.interactive()
