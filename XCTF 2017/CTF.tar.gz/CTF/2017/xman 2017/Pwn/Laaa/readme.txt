I have a dream that one day this nation will rise up.

nc challenges.xctf.org.cn 14004