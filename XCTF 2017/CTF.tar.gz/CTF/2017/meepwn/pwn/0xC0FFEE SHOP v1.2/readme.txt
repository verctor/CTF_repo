Have you tried c0ffee v1.0 & 1.1 at here��https://github.com/l4wio/CTF-challenges-by-me�� ?

I have made another one!!!1

It seems nearly impossible to exploit...can you ?

('139.59.241.86',31334)
Ubuntu 16.04.2 LTS (GNU/Linux 4.4.0-81-generic x86_64)
md5sum(/lib/x86_64-linux-gnu/libc-2.23.so) = 885acc6870b8ba98983e88e578179a2c