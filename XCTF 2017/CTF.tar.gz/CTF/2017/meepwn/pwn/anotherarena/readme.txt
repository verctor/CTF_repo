hm...weird crackme

('139.59.241.76',31335)
Ubuntu 16.04.2 LTS (GNU/Linux 4.4.0-81-generic x86_64)
md5sum(/lib/x86_64-linux-gnu/libc-2.23.so) = 885acc6870b8ba98983e88e578179a2c 