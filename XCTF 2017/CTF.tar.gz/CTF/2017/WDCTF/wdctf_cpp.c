#include <iostream>
#include <string>
#include <vector>
using namespace std;

class message{
public:
    message(int size){
        this->message_list = new string[size];
        this->size = 0;
    }

    ~message(){
        delete this->message_list;
    }

    void print_all_message(){
        int i;
        for(i=0;i<this->size;i++){
            cout << "\t" << i << ":" << this->message_list[i] << endl;
        }
    }

    void set_message(int index,string s){
        this->message_list[index] = s;
        this->size++;
    }

private:
    string* message_list;
    int size;
};

vector<message*> global_message_list;

void do_add(){
    int num,i;
    string tmp_str;
    cout << "how many message do you want to add?" << endl;
    cin >> num;
    message* m = new message(num);
    for(i=0;i<num;i++){
        cout << "give me message" << endl;
        cin >> tmp_str;
        m->set_message(i,tmp_str);
    }
    global_message_list.push_back(m);
}

void do_delete(){
    int index;
    cout << "input index:" << endl;
    cin >> index;
    global_message_list.erase(global_message_list.begin()+index);
    cout << "delete successfully" << endl;
}

void do_print(){
    int count=0;
    cout << "\033[33m";
    for(vector<message*>::iterator iter=global_message_list.begin();
             iter!=global_message_list.end();iter++)
    {
        cout << count++ << ":" <<endl;
        (*iter)->print_all_message();
    }
    cout << "\033[0m";
}

void menu(){
    cout << "1. add message" << endl;
    cout << "2. delete message" << endl;
    cout << "3. print message" << endl;
    cout << "4. exit" << endl;
    cout << ">> ";
}

int main(){
    string sel;
    cout << "Welcome to message cloud" << endl;
    while(1){
        menu();
        cin >> sel;
        if(sel == "1"){
            do_add();
        }
        if(sel == "2"){
            do_delete();
        }
        if(sel == "3"){
            do_print();
        }
        if(sel == "4"){
            cout << "bye!" << endl;
            break;
        }
    }
}
