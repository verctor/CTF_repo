#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
char* get_line()
{
	char* ptr;
    int i,j;
    ptr = (char*)malloc(0x100);
    if(ptr){
        for(j=0;;j++){
            for(i=0;i<0x100;i++){
                if(read(1,ptr+i+0x100*j,1) != 1){
                    fprintf(stderr,"read error!");
                    free(ptr);
                    exit(0);
                }
                if(*(ptr+i+0x100*j) == '\n'){
//                    puts("read ok!\nstart analyse!");
                    *(ptr+i+0x100*j) = 0;
                    return ptr;
                }
                if(*(ptr+i+0x100*j) == ' ') i--;
            }    
            ptr = (char*)realloc(ptr,0x100*(j+2));
            if(!ptr) {
                fprintf(stderr,"realloc error!");    
                free(ptr);
                exit(1);
            }
        }
    }
    else{
        fprintf(stderr,"nomore space:(");
        free(ptr);
        exit(1);
    }
}

int check_byte_range(char* buffer){
    while(*buffer!=0){
        if(
            ((*buffer >= 0x7a || *buffer <0x30)||
            (*buffer >= 0x5b&&*buffer <= 0x60)||
            (*buffer >= 0x3a&&*buffer <=0x40))&&
            (*buffer != '+'&&*buffer != '-'&&*buffer != '*'&&
            *buffer != '/'&&*buffer != ')'&&*buffer != '('&&
            *buffer != '_'&&*buffer != ' ')
        ){
            return 0;
        }
        buffer++;
    }
    return 1;
}

int get_ch_priority(char ch){
    if(ch == '('||ch == ')') return 3;
    if(ch == '*'||ch == '/') return 2;
    if(ch == '+'||ch == '-') return 1;
    return 0;    
}

char* infix_to_postfix(char* buffer)
{
    char* sp;
    int priority,bracket_state = 0;
    int lenth = strlen(buffer);
    char* stack = (char*)malloc(lenth);
    char* output = (char*)malloc(2*lenth);
    char* pre_output = output;
    char* pre_buffer = buffer;
    if(!stack||!output){
        fprintf(stderr,"malloc error...");
        free(pre_buffer);
                free(stack);
                free(pre_output);
        exit(1);
    }

    sp = stack-1;

    for(;*buffer!=0;buffer++)
    {
        priority = get_ch_priority(*buffer);
        if(!priority){
            *output++ = *buffer; 
            continue;
        }

        if(*buffer == '('){
            sp++;
            *sp = *buffer;
            bracket_state++;
            continue;
        }

        if(*buffer == ')'){
            if(bracket_state){
                while(*sp != '('){
                        *output++ = *sp--;
                }
                sp--;
                bracket_state--;
            }
            else{
                fprintf(stderr,"error at ')'...");
                free(pre_buffer);
                free(stack);
                free(pre_output);
                exit(1);
            }
            continue;
        }

        *output++ = ' ';

        if(sp < stack) {
            sp++;
            *sp = *buffer; 
            continue;
        }

        if(priority > get_ch_priority(*sp)){
            sp++;
            *sp = *buffer;
            continue;
        }

        while(priority <= get_ch_priority(*sp)){
            if(bracket_state){
                if(*sp == '(')
                    break;
            }
            *output++ = *sp--;
            if(sp < stack) break;
        }
        sp++;
        *sp = *buffer;
    }
    if(bracket_state){
        fprintf(stderr,"blacket error...\n");
        free(pre_buffer);
            free(stack);
        free(pre_output);
        exit(1);
    }
    while(sp >= stack){
        *output++ = *sp--;
    }
    free(pre_buffer);
    free(stack);
    return pre_output;
}

int is_number(char ch){
    return ch >= '0' && ch <='9';
}

void cacl(char* input)
{
    int num = 0;
    int* stack = (int*)malloc(strlen(input)*sizeof(int));
    int* sp = stack;
    while(1){
        if(is_number(*input)){
            num = 0; 
            while(is_number(*input)){
                num = num*10+*input-0x30;
                input++;
            }   
            *sp++ = num;
        }
        else if(!*input){
            break; 
        }
        else{
            switch(*input++){
            case '+':
                *(sp-2) += *(sp-1);
                sp-=1;
                break;
            case '-':
                *(sp-2) -= *(sp-1);
                sp-=1;
                break;
            case '*':
                *(sp-2) *= *(sp-1);
                sp-=1;
                break;
            case '/':
                *(sp-2) /= *(sp-1);
                sp-=1;
                break;
            }
        }
        if(*input == ' '){
            input++;
        }
    }
    printf("%d\n",*(sp-1));
    free(stack);
}

void welcome(){
    printf("> ");
}

int main(void){
    char* output;
    char* buffer;
    setbuf(stdin,0);
    setbuf(stdout,0);
    setbuf(stderr,0);
    while(1){
        welcome();
        buffer = get_line();
        if(!check_byte_range(buffer)){
            fprintf(stderr,"range error:(");
            free(buffer);
            exit(1);
        }
        output = infix_to_postfix(buffer);
    //    puts("postfix express:");
    //    puts(output);
        cacl(output);
        free(output);
    }
}
